import fs from 'node:fs';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {INPUT_STAGE,prepareCohort,predictCohort,resultsCSV,parseDelimited} from './prediction/engine.mjs';
import {addSurvival,clinicalRows} from './prediction/clinical-cohort.mjs';
const model=JSON.parse(fs.readFileSync(new URL('./prediction/model.json',import.meta.url)));
const clinical=JSON.parse(fs.readFileSync(new URL('./prediction/nomogram.json',import.meta.url)));
const expected=JSON.parse(fs.readFileSync(new URL('./examples/preprocessed_expected.json',import.meta.url)));
const text=fs.readFileSync(new URL('./examples/preprocessed_template.csv',import.meta.url),'utf8');
const prepared=prepareCohort(text,model);
const run=samples=>predictCohort({samples,input_stage:INPUT_STAGE},model);
test('unchanged frozen-network reference',()=>assert.deepEqual(run(prepared.samples).results.map(r=>r.score),expected.scores));
test('single-row / batch score identity',()=>prepared.samples.forEach((s,i)=>assert.equal(run([s]).results[0].score,expected.scores[i])));
test('reordering / appended rows cannot change existing scores',()=>{
  assert.deepEqual(run([...prepared.samples].reverse()).results.map(r=>r.score),[...expected.scores].reverse());
  const added={id:'extra',values:prepared.samples[0].values.map(v=>v+1)};
  assert.deepEqual(run([...prepared.samples,added]).results.slice(0,2).map(r=>r.score),expected.scores);
});
test('columns map by gene name',()=>{
  const rows=parseDelimited(text),ix=[0,...rows[0].slice(1).map((_,i)=>i+1).reverse()];
  const shuffled=rows.map(r=>ix.map(i=>r[i]).join(',')).join('\n');
  assert.deepEqual(prepareCohort(shuffled,model),prepared);
});
test('raw input / wrong stage rejected',()=>{
  assert.throws(()=>prepareCohort('sample_id,RNF43\na,1',model),/Preprocessed/);
  assert.throws(()=>prepareCohort(text.replaceAll(INPUT_STAGE,'raw_expression'),model),/input_stage/);
  assert.throws(()=>predictCohort({samples:prepared.samples},model),/declaration/);
});
test('missing gene, NaN, duplicate sample, empty file rejected',()=>{
  assert.throws(()=>prepareCohort(text.replace('RNF43','not_a_gene'),model),/Missing/);
  const rows=parseDelimited(text);rows[1][2]='NaN';assert.throws(()=>prepareCohort(rows.map(r=>r.join(',')).join('\n'),model),/invalid/);
  rows[1][2]='0.5';rows[2][0]=rows[1][0];assert.throws(()=>prepareCohort(rows.map(r=>r.join(',')).join('\n'),model),/duplicate/);
  assert.throws(()=>prepareCohort('',model));
});
test('invalid network scale and vectors rejected',()=>{
  assert.throws(()=>run([{id:'bad',values:[1]}]));
  assert.throws(()=>predictCohort(prepared,{...model,sd:model.sd.map(()=>0)}),/scale/);
});
test('single input has no artificial risk group; output records interface',()=>{
  const a=run([prepared.samples[0]]);assert.equal(a.results[0].relative_hazard,null);
  assert.equal(a.results[0].group,'Not assigned (single sample)');
  assert(resultsCSV(a,'colorectal').includes(model.interface_version));
});
test('unchanged nomogram remains matched to checkpoint',()=>{
  for(const cancer of ['colorectal','gastric','pancreatic']){
    const a=run(prepared.samples);addSurvival(a,clinicalRows(text),cancer,clinical);
    a.results.forEach(r=>{const s=r.nomogram.survival;assert(s.every(v=>v>=0&&v<=1));assert(s[0]>=s[1]&&s[1]>=s[2]);});
  }
  assert.throws(()=>addSurvival({...run(prepared.samples),source_sha256:'different'},clinicalRows(text),'colorectal',clinical),/checkpoint/);
});
test('CSV quotation and TSV input',()=>{
  assert.deepEqual(parseDelimited('a,b\n"x,y","z"'),[['a','b'],['x,y','z']]);
  assert.deepEqual(prepareCohort(text.replaceAll(',','\t'),model),prepared);
});
