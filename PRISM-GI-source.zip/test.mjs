import fs from 'node:fs';
import assert from 'node:assert/strict';
import {prepareCohort,predictCohort} from './prediction/engine.mjs';
import {predictNomogram} from './prediction/nomogram.mjs';
const model=JSON.parse(fs.readFileSync(new URL('./prediction/model.json',import.meta.url)));
const clinical=JSON.parse(fs.readFileSync(new URL('./prediction/nomogram.json',import.meta.url)));
const input=fs.readFileSync(new URL('./examples/synthetic_input.csv',import.meta.url),'utf8');
const a=predictCohort(prepareCohort(input,model),model);
assert.equal(a.n,2);assert(a.results.every(r=>Number.isFinite(r.score)));
assert.deepEqual(a,predictCohort(prepareCohort(input,model),model));
assert.throws(()=>prepareCohort('',model));
assert.throws(()=>prepareCohort('sample_id,RNF43\na,1\nb,2',model));
for(const cancer of ['colorectal','gastric','pancreatic']){
  const p=predictNomogram({cancer,age:60,stage:2,score:a.results[0].score},clinical);
  assert(p.survival.every(v=>Number.isFinite(v)&&v>=0&&v<=1));
  assert(p.survival[0]>=p.survival[1]&&p.survival[1]>=p.survival[2]);
}
assert.throws(()=>predictNomogram({cancer:'other',age:60,stage:2,score:0},clinical));
console.log('PASS: synthetic prediction, determinism, input rejection, nomogram ranges/order.');
