export function predictNomogram(input,model) {
  const {cancer,age,stage,score}=input;
  if(!Object.hasOwn(model.baseline_hazard,cancer)) throw new Error('Select a supported cancer type.');
  if(typeof age!=='number'||!Number.isFinite(age)||age<18||age>100) throw new Error('Enter an age between 18 and 100 years.');
  if(!Number.isInteger(stage)||stage<1||stage>4) throw new Error('Select AJCC overall stage I, II, III or IV.');
  if(typeof score!=='number'||!Number.isFinite(score)) throw new Error('Enter the raw PRISM-GI score, not relative hazard or a percentile.');
  const x={risk:score,age_per10:age/10,stage_2:Number(stage===2),stage_3:Number(stage===3),stage_4:Number(stage===4)};
  let lp=0,uncentered=0;
  for(const k of Object.keys(model.coefficient)){lp+=(x[k]-model.centering[k])*model.coefficient[k];uncentered+=x[k]*model.coefficient[k];}
  const hazard=Math.exp(lp);
  if(!Number.isFinite(hazard)||hazard===0) throw new Error('Score is outside the supported numerical range. Check that you entered the raw model score.');
  const warnings=[];
  for(const [k,v] of [['age',age],['risk',score]]){const [lo,hi]=model.training_ranges[k];if(v<lo||v>hi)warnings.push(`${k==='risk'?'Score':'Age'} is outside the observed training range (${lo.toFixed(2)} to ${hi.toFixed(2)}); this estimate is extrapolative.`);}
  if(cancer==='pancreatic')warnings.push('The combined pancreatic nomogram could not be externally evaluated in the GEO cohorts because required clinical variables were missing.');
  return {cancer,age,stage,score,centered_log_hazard:lp,total_points:(uncentered-model.points.minimum_uncentered_lp)*model.points.points_per_log_hazard,
    survival:model.baseline_hazard[cancer].map(h=>Math.exp(-h*hazard)),warnings};
}
