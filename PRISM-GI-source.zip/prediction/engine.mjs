// Preprocessed-feature inference only: no ranking or domain correction.
export const INPUT_STAGE='domain_adjusted_rank';
export function parseDelimited(text) {
  if(typeof text!=='string'||!text.trim())throw new Error('The input file is empty.');
  text=text.replace(/^\uFEFF/,'');
  const delim=text.split(/\r?\n/,1)[0].includes('\t')?'\t':',';
  const rows=[];let row=[],field='',quoted=false,afterQuote=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;afterQuote=true;}}else field+=c;continue;}
    if(c==='"'){if(field.length||afterQuote)throw new Error('Malformed CSV quoting.');quoted=true;continue;}
    if(c===delim){row.push(field);field='';afterQuote=false;continue;}
    if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';afterQuote=false;continue;}
    if(afterQuote&&!/\s/.test(c))throw new Error('Unexpected text after a quoted field.');
    if(!afterQuote)field+=c;
  }
  if(quoted)throw new Error('Unclosed quoted field.');
  row.push(field);if(row.some(x=>x.trim()))rows.push(row);
  return rows;
}
export function validateModel(m){
  const p=m.genes?.length;
  if(m.input_stage!==INPUT_STAGE||!p||new Set(m.genes).size!==p)throw new Error('Incompatible model input contract.');
  const vec=(x,n)=>Array.isArray(x)&&x.length===n&&x.every(v=>typeof v==='number'&&Number.isFinite(v));
  if(!vec(m.mean,p)||!vec(m.sd,p)||m.sd.some(v=>v<=0))throw new Error('Invalid frozen training scale.');
  if(!Array.isArray(m.weights)||!m.weights.length||!m.weights.every(w=>vec(w,p))||!vec(m.bias,m.weights.length)||!vec(m.output_weights,m.weights.length))throw new Error('Invalid frozen network parameters.');
}
export function prepareCohort(text,model){
  validateModel(model);
  const rows=parseDelimited(text),header=rows.shift().map(x=>x.trim());
  if(header[0]!=='sample_id')throw new Error('The first column must be sample_id.');
  if(new Set(header).size!==header.length)throw new Error('Duplicate column names are not allowed.');
  const stage=header.indexOf('input_stage');
  if(stage<0)throw new Error('Preprocessed inputs only: input_stage=domain_adjusted_rank is required. Raw expression is not accepted. See README.md.');
  if(!rows.length||rows.length>10000)throw new Error('Provide between 1 and 10,000 samples.');
  const cols=model.genes.map(g=>({gene:g,index:header.indexOf(g)}));
  const missing=cols.filter(c=>c.index<0).map(c=>c.gene);
  if(missing.length)throw new Error('Missing processed model features: '+missing.join(', '));
  const allowed=new Set(['sample_id','input_stage','age','stage',...model.genes]);
  if(header.some(h=>!allowed.has(h)))throw new Error('Unexpected columns. Supply 15 processed features and optional age/stage only.');
  const ids=new Set();
  const samples=rows.map((row,r)=>{
    if(row.length!==header.length)throw new Error(`Row ${r+2}: wrong number of fields.`);
    if(row[stage].trim()!==INPUT_STAGE)throw new Error(`Row ${r+2}: input_stage must be ${INPUT_STAGE}, not raw expression or standardized z scores.`);
    const id=row[0].trim();if(!id||ids.has(id))throw new Error(`Row ${r+2}: empty or duplicate sample ID.`);ids.add(id);
    const values=cols.map(c=>{
      const v=row[c.index].trim();
      if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(v)||!Number.isFinite(Number(v)))throw new Error(`Row ${r+2}: invalid ${c.gene} feature.`);
      return Number(v);
    });
    return {id,values};
  });
  return {samples,input_stage:INPUT_STAGE};
}
export function predictCohort(prepared,model){
  validateModel(model);
  if(prepared.input_stage!==INPUT_STAGE)throw new Error('Explicit preprocessed-input declaration is required.');
  const samples=prepared.samples,n=samples.length;
  if(!n)throw new Error('No samples.');
  const results=samples.map(row=>{
    if(!Array.isArray(row.values)||row.values.length!==model.genes.length||!row.values.every(v=>typeof v==='number'&&Number.isFinite(v)))throw new Error('Invalid processed feature vector.');
    const z=row.values.map((v,j)=>Math.fround((v-model.mean[j])/model.sd[j]));
    const hidden=model.weights.map((w,h)=>Math.fround(Math.tanh(w.reduce((s,v,j)=>s+v*z[j],model.bias[h]))));
    const score=Math.fround(hidden.reduce((s,v,h)=>s+v*model.output_weights[h],0));
    if(!Number.isFinite(score))throw new Error('Non-finite model output.');
    return {sample_id:row.id,score};
  });
  const sorted=results.map(r=>r.score).sort((a,b)=>a-b),median=n%2?sorted[(n-1)/2]:(sorted[n/2-1]+sorted[n/2])/2;
  for(const r of results){r.relative_hazard=n>1?Math.exp(r.score-median):null;r.group=n===1?'Not assigned (single sample)':r.score>median?'Above cohort median':r.score<median?'Below cohort median':'At cohort median';}
  return {results,median,min:sorted[0],max:sorted[n-1],n,model_version:model.version,interface_version:model.interface_version,source_sha256:model.source_sha256,input_stage:INPUT_STAGE};
}
export function resultsCSV(output,cancer){
  const safe=v=>'"'+String(v).replace(/^[=+@\-\t\r]/,"'$&").replaceAll('"','""')+'"';
  return ['sample_id,cancer,prism_gi_score,relative_hazard_vs_cohort_median,cohort_group,model_version,interface_version,input_stage',...output.results.map(r=>[safe(r.sample_id),safe(cancer),r.score.toPrecision(10),r.relative_hazard===null?'':r.relative_hazard.toPrecision(10),safe(r.group),safe(output.model_version),safe(output.interface_version),safe(output.input_stage)].join(','))].join('\r\n');
}
