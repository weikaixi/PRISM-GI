export function parseDelimited(text) {
  if(typeof text!=='string'||!text.trim()) throw new Error('The file is empty. Choose a CSV or TSV expression matrix.');
  text=text.replace(/^\uFEFF/,'');
  const delim=text.split(/\r?\n/,1)[0].includes('\t')?'\t':',';
  const rows=[];let row=[],field='',quoted=false,afterQuote=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;afterQuote=true;}}else field+=c;continue;}
    if(c==='"'){if(field.length||afterQuote)throw new Error('Malformed CSV quoting.');quoted=true;continue;}
    if(c===delim){row.push(field);field='';afterQuote=false;continue;}
    if(c==='\n'||c==='\r'){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(x=>x.trim()))rows.push(row);row=[];field='';afterQuote=false;continue;}
    if(afterQuote&&!/\s/.test(c))throw new Error('Unexpected text after a quoted field.');
    if(!afterQuote)field+=c;
  }
  if(quoted)throw new Error('Unclosed quoted field.');
  row.push(field);if(row.some(x=>x.trim()))rows.push(row);
  return rows;
}

export function prepareCohort(text,model){
  const rows=parseDelimited(text);const header=rows.shift().map(x=>x.trim());
  if(!['sample_id','sample'].includes(header[0]?.toLowerCase()))throw new Error('The first column must be sample_id. Use the downloadable template (samples in rows).');
  if(new Set(header).size!==header.length)throw new Error('Duplicate column names are not allowed.');
  if(rows.length<2)throw new Error('At least 2 samples from the same source cohort are required. Single-patient scoring is not supported.');
  if(rows.length>10000)throw new Error('This browser tool supports up to 10,000 samples per run.');
  const cols=model.rank_pool.map(g=>({gene:g,index:header.indexOf(g)})).filter(x=>x.index>0);
  const missing=model.genes.filter(g=>!cols.some(x=>x.gene===g));
  if(missing.length)throw new Error('Missing model genes: '+missing.join(', ')+'. All 15 model genes are required.');
  if(cols.length<model.minimum_background_genes)throw new Error(`Only ${cols.length}/158 background genes found. Provide at least ${model.minimum_background_genes}, including all 15 model genes. Do not rank only the 15 genes.`);
  const ids=new Set();const panelIndex=model.genes.map(g=>cols.findIndex(c=>c.gene===g));
  const ranks=rows.map((row,r)=>{
    if(row.length!==header.length)throw new Error(`Row ${r+2} has ${row.length} fields; expected ${header.length}.`);
    const id=row[0].trim();if(!id||ids.has(id))throw new Error(`Empty or duplicate sample ID at row ${r+2}.`);ids.add(id);
    const values=cols.map(c=>{
      const raw=row[c.index].trim();
      if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(raw)||!Number.isFinite(Number(raw)))throw new Error(`Non-numeric or missing ${c.gene} value at row ${r+2}. Omit a completely unmeasured background gene column; do not leave blank cells.`);
      return Number(raw);
    });
    const order=values.map((v,i)=>({v,i})).sort((a,b)=>a.v-b.v);const allRanks=new Array(values.length);
    for(let i=0;i<order.length;){let j=i+1;while(j<order.length&&order[j].v===order[i].v)j++;const rank=((i+1)+j)/2/order.length;for(let k=i;k<j;k++)allRanks[order[k].i]=rank;i=j;}
    return {id,values:panelIndex.map(i=>allRanks[i])};
  });
  return {samples:ranks,available:cols.length,missingBackground:model.rank_pool.filter(g=>!cols.some(c=>c.gene===g)),ignoredColumns:header.length-1-cols.length-header.filter(c=>['age','stage'].includes(c)).length};
}

export function predictCohort(prepared,model){
  const samples=prepared.samples,n=samples.length;
  const mean=model.genes.map((_,j)=>samples.reduce((s,r)=>s+r.values[j],0)/n);
  const results=samples.map(row=>{
    const z=row.values.map((v,j)=>Math.fround((v-model.lambda_value*(mean[j]-model.training_global[j])-model.mean[j])/model.sd[j]));
    const hidden=model.weights.map((w,h)=>Math.fround(Math.tanh(w.reduce((s,v,j)=>s+v*z[j],model.bias[h]))));
    const risk=Math.fround(hidden.reduce((s,v,h)=>s+v*model.output_weights[h],0));
    if(!Number.isFinite(risk))throw new Error('A non-finite model output was encountered. Check the input scale.');
    return {sample_id:row.id,score:risk};
  });
  const sorted=results.map(r=>r.score).sort((a,b)=>a-b);const median=n%2?sorted[(n-1)/2]:(sorted[n/2-1]+sorted[n/2])/2;
  for(const r of results){r.relative_hazard=Math.exp(r.score-median);r.group=r.score>median?'Above cohort median':r.score<median?'Below cohort median':'At cohort median';}
  return {results,median,min:sorted[0],max:sorted[n-1],n,available:prepared.available,missingBackground:prepared.missingBackground,ignoredColumns:prepared.ignoredColumns};
}

export function resultsCSV(output,cancer){
  const safe=v=>'"'+String(v).replace(/^[=+@\-\t\r]/,"'$&").replaceAll('"','""')+'"';
  return ['sample_id,cancer,prism_gi_score,relative_hazard_vs_cohort_median,cohort_group,lambda,model_version',...output.results.map(r=>[safe(r.sample_id),safe(cancer),r.score.toPrecision(10),r.relative_hazard.toPrecision(10),safe(r.group),0.5,'frozen-deepsurv-v1'].join(','))].join('\r\n');
}
