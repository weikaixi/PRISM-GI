import {parseDelimited, resultsCSV} from './engine.mjs';
import {predictNomogram} from './nomogram.mjs';

export function clinicalRows(text){
  const [header,...rows]=parseDelimited(text);const h=header.map(s=>s.trim());
  return rows.map(r=>({sample_id:r[0].trim(),age:h.includes('age')?r[h.indexOf('age')].trim():'',stage:h.includes('stage')?r[h.indexOf('stage')].trim():''}));
}
export function normalizeStage(value){return ({I:1,II:2,III:3,IV:4})[String(value).trim().toUpperCase()]??Number(value);}
export function addSurvival(output,clinical,cancer,model){
  const byId=new Map(clinical.map(r=>[r.sample_id,r]));
  const predictions=output.results.map(r=>{const c=byId.get(r.sample_id);try{
    return predictNomogram({cancer,score:r.score,age:c?.age===''?NaN:Number(c?.age),stage:normalizeStage(c?.stage)},model);
  }catch(e){throw new Error(`${r.sample_id}: ${e.message}`);}});
  output.results.forEach((r,i)=>{r.nomogram=predictions[i];});return output;
}
export function combinedCSV(output,cancer){
  if(!output.results[0]?.nomogram)return resultsCSV(output,cancer);
  const rows=resultsCSV(output,cancer).split('\r\n');
  rows[0]+=',age,ajcc_stage,nomogram_total_points,survival_1y,survival_3y,survival_5y,research_only';
  output.results.forEach((r,i)=>{const n=r.nomogram;rows[i+1]+=','+[n.age,n.stage,n.total_points,...n.survival,true].join(',');});
  return rows.join('\r\n');
}
