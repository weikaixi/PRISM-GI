# Single-cell source code

These are the original analysis scripts, not an automated end-to-end download service. They retain their input checks, annotation scope and provenance. Run from a repository checkout after arranging public inputs/intermediates in the workspace structure referenced by each script. Large matrices, patient mappings, clinical data and manuscript output files are not bundled.

Suggested source order:

1. `analyze_crc_single_cell.py`: author-filtered CRC counts, QC and patient-balanced gene localization. Its default entry point also refers to a pilot cohort; use the functions for the desired accession.
2. `extend_three_cancer_localization.py`: GC/PAAD source readers and conservative broad marker annotations.
3. `build_gc_paad_epithelial_full.py`: full-source QC and doublet detection; prerequisite annotations for subsequent scoring.
4. `plot_crc_single_cell_embedding.py`: CRC UMAP display, excluding panel genes from HVGs.
5. `score_panel_single_cells.py`: exact-tie UCell-style enrichment, separate cohort t-SNE, patient summaries. Missing source MUC2 is not a zero expression measurement; common-panel analyses are explicitly 14 genes where needed.
6. `legacy_model_single_cell_scores.py`: original frozen-model scores and raw-count-summed patient × cell-type pseudobulk. No refitting. This script also verifies the frozen artifact against local bulk reference files and reconstructs training-derived ranges for extrapolation checks; those local files must be supplied separately. The validation is not model training or CV.
7. `validate_legacy_single_cell_scores.py` and `validate_panel_signature_results.py`: independent consistency and coverage checks.

The scripts use their original result directories under `outputs/single_cell_virtual_v1`. The 15-gene frozen score, unsigned UCell enrichment, and mean cell score versus pseudobulk score are different quantities; do not substitute one for another.

Install the Python packages in `requirements-single-cell.txt` in a suitable Python environment. Full-source analysis needs substantial RAM. Versions in the original saved analysis protocols should be used for exact historical reproduction; the requirements file lists minimum API requirements, not a validated frozen environment.
