"""Full-source QC and conservative marker-supported preliminary localization.

No phenotype transfer, no OS risk assigned to cells, no inferred malignancy.
All panel genes are excluded from annotation markers.
"""
import csv,gzip,io,json,tarfile,re,gc
from pathlib import Path
import numpy as np
import pandas as pd
import anndata as ad
import h5py
from scipy import sparse
from scipy.io import mmread
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from threadpoolctl import threadpool_limits
from analyze_crc_single_cell import O,GENES

D=O/'three_cancer_localization_v1';D.mkdir(exist_ok=True)
MARKERS={
 'Epithelial':['EPCAM','KRT8','KRT18','KRT19'],
 'T':['CD3D','CD3E','TRAC','CD2'],
 'NK':['NKG7','GNLY','KLRD1','PRF1'],
 'B':['MS4A1','CD79A','CD79B','CD37'],
 'Plasma':['MZB1','JCHAIN','SDC1','DERL3'],
 'Myeloid':['LST1','TYROBP','FCER1G','AIF1'],
 'Fibroblast':['COL1A1','COL1A2','DCN','LUM'],
 'Endothelial':['PECAM1','VWF','EMCN','KDR'],
 'Pericyte':['RGS5','MCAM','NOTCH3','CSPG4'],
 'Mast':['KIT','TPSAB1','TPSB2','CPA3'],
 'Acinar':['PRSS1','PRSS2','CPA1','CTRB2'],
 'Endocrine':['CHGA','CHGB','PCSK1','ISL1']}
assert not set(GENES)&set(sum(MARKERS.values(),[]))
BROAD={'Epithelial':'Epithelial','Acinar':'Epithelial','Endocrine':'Epithelial',
 'T':'T/NK','NK':'T/NK','B':'B/Plasma','Plasma':'B/Plasma','Myeloid':'Myeloid',
 'Fibroblast':'Stromal','Endothelial':'Stromal','Pericyte':'Stromal','Mast':'Mast','Uncertain':'Uncertain'}


def annotate(raw,genes):
    total=np.asarray(raw.sum(1)).ravel(); detected=raw.getnnz(1)
    mt=np.array([str(g).upper().startswith('MT-') for g in genes])
    mtfrac=np.asarray(raw[:,mt].sum(1)).ravel()/np.maximum(total,1)
    passed=(detected>=500)&(detected<6000)&(total>=500)&(mtfrac<=.2)
    scores=[];counts=[]
    for markers in MARKERS.values():
        pos=[genes.get_loc(g) for g in markers if g in genes]
        q=raw[:,pos].toarray()
        scores.append(np.log1p(q/np.maximum(total[:,None],1)*10000).sum(1)/len(markers))
        counts.append((q>0).sum(1))
    s=np.array(scores).T;n=np.array(counts).T
    top=s.argmax(1);v=s[np.arange(len(s)),top];gap=v-np.partition(s,-2,axis=1)[:,-2]
    labels=np.array(list(MARKERS),dtype=object)[top]
    accepted=(n[np.arange(len(n)),top]>=2)&(v>=.5)&(gap>=.25)
    labels[~accepted]='Uncertain'
    return pd.DataFrame({'total_UMI':total,'detected_genes':detected,'mt_fraction':mtfrac,
      'QC_pass':passed,'marker_label':labels,'broad_label':[BROAD[x] for x in labels],
      'marker_score':v,'marker_margin':gap})


def dedup(raw,genes):
    idx=pd.Index(genes)
    if idx.is_unique:return raw,idx
    code,unique=pd.factorize(idx,sort=False)
    mapping=sparse.csr_matrix((np.ones(len(idx)),(np.arange(len(idx)),code)),shape=(len(idx),len(unique)))
    return (raw@mapping).astype(np.int64).tocsr(),pd.Index(unique)


def gc_samples():
    mapping=pd.read_csv(O/'GSE183904_patient_sample_mapping.csv').set_index('sample_file')
    with tarfile.open(O/'source_data/GSE183904/GSE183904_RAW.tar') as archive:
        for member in archive.getmembers():
            if not member.isfile() or not member.name.endswith('.csv.gz'):continue
            sample=member.name.split('_',1)[1].removesuffix('.gz');meta=mapping.loc[sample]
            if not meta.tissue_class.startswith('Primary_'):continue
            blocks=[];genes=[]
            with gzip.open(archive.extractfile(member),'rt') as f:
                cells=next(csv.reader([f.readline()]))[1:]
                # Chunked CSV avoids dense full-expression matrices in memory.
                for chunk in pd.read_csv(f,header=None,index_col=0,chunksize=256):
                    vals=chunk.to_numpy(dtype=float)
                    assert np.isfinite(vals).all() and (vals>=0).all() and (vals==np.floor(vals)).all()
                    genes.extend(chunk.index.astype(str));blocks.append(sparse.csr_matrix(vals.astype(np.int32)))
            raw=sparse.vstack(blocks).T.tocsr();del blocks
            assert raw.shape[0]==len(cells)
            raw,genes=dedup(raw,genes)
            yield 'GSE183904',sample,str(meta.patient_id),str(meta.tissue_class),raw,genes,cells


def paad_samples():
    for path in sorted((O/'source_data/GSE155698').glob('*.tar.gz')):
        sample=path.name.split('_',1)[1].removesuffix('.tar.gz')
        with tarfile.open(path) as archive:
            names=archive.getnames();matrix=next((n for n in names if n.endswith('matrix.mtx.gz')),None)
            if matrix:
                with gzip.open(archive.extractfile(matrix),'rb') as f:raw=mmread(f).T.tocsr()
                features=next(n for n in names if n.endswith('features.tsv.gz'))
                barcodes=next(n for n in names if n.endswith('barcodes.tsv.gz'))
                with gzip.open(archive.extractfile(features),'rt') as f:genes=[s.rstrip().split('\t')[1] for s in f]
                with gzip.open(archive.extractfile(barcodes),'rt') as f:cells=f.read().splitlines()
            else:
                name=next(n for n in names if n.endswith('.h5'))
                with h5py.File(io.BytesIO(archive.extractfile(name).read())) as f:
                    root=f['matrix'] if 'matrix' in f else f[next(iter(f.keys()))]
                    raw=sparse.csc_matrix((root['data'][:],root['indices'][:],root['indptr'][:]),shape=root['shape'][:]).T.tocsr()
                    feature=root['features/name'] if 'features' in root else root['gene_names']
                    genes=[g.decode() for g in feature[:]];cells=[g.decode() for g in root['barcodes'][:]]
        assert np.isfinite(raw.data).all() and (raw.data>=0).all() and (raw.data==np.floor(raw.data)).all()
        raw,genes=dedup(raw,genes)
        # Explicit GEO GSM4710699 description confirms 11A/B same patient.
        patient=re.sub(r'11[AB]$','11',sample)
        tissue='Primary_Tumor' if sample.startswith('PDAC') else 'Primary_Normal'
        yield 'GSE155698',sample,patient,tissue,raw,genes,cells


def process(acc,sample,patient,tissue,raw,genes,cells):
    prefix=D/f'{acc}_{sample.replace(".csv","")}'
    ann=annotate(raw,genes);ann.index=[sample+'|'+str(z) for z in cells]
    ann['patient']=patient;ann['sample']=sample;ann['tissue']=tissue
    ann.to_csv(str(prefix)+'_QC_annotations.csv.gz')
    available=[g for g in GENES if g in genes]
    values=raw[:,genes.get_indexer(available)].toarray()
    log=np.log1p(values/np.maximum(ann.total_UMI.to_numpy()[:,None],1)*10000)
    rows=[]
    for label,loc in ann[ann.QC_pass].groupby('broad_label').indices.items():
        # groupby indices refer to the filtered frame; restore original positions.
        original=np.flatnonzero(ann.QC_pass.to_numpy())[loc]
        for j,g in enumerate(available):
            rows.append(dict(accession=acc,patient=patient,sample=sample,tissue=tissue,cell_type=label,gene=g,
              n_cells=len(original),detected_cells=int((values[original,j]>0).sum()),logsum=float(log[original,j].sum())))
    pd.DataFrame(rows).to_csv(str(prefix)+'_panel_sums.csv',index=False)
    pd.DataFrame({'gene':GENES,'available':[g in genes for g in GENES]}).to_csv(str(prefix)+'_gene_coverage.csv',index=False)
    # Preserve a small sample-balanced full transcriptome set for preliminary UMAP.
    rng=np.random.default_rng(20260917)
    good=np.flatnonzero(ann.QC_pass.to_numpy());idx=rng.choice(good,min(400,len(good)),replace=False)
    a=ad.AnnData(raw[idx],obs=ann.iloc[idx].copy(),var=pd.DataFrame(index=genes))
    a.write_h5ad(str(prefix)+'_display_counts.h5ad',compression='gzip')
    status=dict(accession=acc,sample=sample,patient=patient,tissue=tissue,source_cells=len(cells),QC_cells=int(ann.QC_pass.sum()),
      marker_accepted_cells=int((ann.QC_pass&(ann.broad_label!='Uncertain')).sum()),panel_available=len(available))
    Path(str(prefix)+'_status.json').write_text(json.dumps(status,indent=2))
    print(status,flush=True)


def summary():
    statuses=[json.loads(p.read_text()) for p in D.glob('*_status.json')]
    pd.DataFrame(statuses).to_csv(D/'sample_QC_summary.csv',index=False)
    rows=pd.concat([pd.read_csv(p) for p in D.glob('*_panel_sums.csv')],ignore_index=True)
    p=rows.groupby(['accession','patient','tissue','cell_type','gene'])[['n_cells','detected_cells','logsum']].sum().reset_index()
    p['fraction_detected']=p.detected_cells/p.n_cells;p['mean_log1p_CP10K']=p.logsum/p.n_cells
    p.to_csv(D/'patient_15gene_localization.csv',index=False)
    s=p[p.n_cells>=20].groupby(['accession','tissue','cell_type','gene']).agg(
      mean_log1p_CP10K=('mean_log1p_CP10K','mean'),fraction_detected=('fraction_detected','mean'),patients=('patient','nunique')).reset_index()
    s.to_csv(D/'patient_balanced_15gene_localization.csv',index=False)
    crc=pd.read_csv(O/'GSE132465/patient_balanced_celltype_15gene_author_QC.csv');crc=crc[crc.Class=='Tumor'].copy()
    crc['accession']='GSE132465';crc['tissue']='Primary_Tumor';crc['cell_type']=crc.Cell_type.map({'Epithelial cells':'Epithelial','Stromal cells':'Stromal','T cells':'T/NK','Myeloids':'Myeloid','B cells':'B/Plasma','Mast cells':'Mast'})
    allp=pd.concat([crc,s[s.tissue=='Primary_Tumor']])
    ctypes=['Epithelial','Stromal','T/NK','Myeloid','B/Plasma','Mast']
    fig,axes=plt.subplots(1,3,figsize=(18,6.5),sharey=True)
    vmax=float(allp.mean_log1p_CP10K.max())
    for ax,acc,title in zip(axes,['GSE132465','GSE183904','GSE155698'],['CRC: author labels','GC: provisional marker labels','PAAD: provisional marker labels']):
        q=allp[allp.accession==acc].set_index(['cell_type','gene'])
        for i,g in enumerate(GENES):
            for j,ct in enumerate(ctypes):
                if (ct,g) not in q.index:ax.plot(i,j,'x',color='.7',ms=4);continue
                r=q.loc[(ct,g)]
                ax.scatter(i,j,s=8+160*r.fraction_detected,c=[r.mean_log1p_CP10K],vmin=0,vmax=vmax,cmap='viridis')
        ax.set_xticks(range(15),GENES,rotation=65,ha='right',fontsize=9);ax.set_yticks(range(6),ctypes);ax.set_title(title+'\n'+acc,fontsize=12)
        ax.set_ylim(5.5,-.5);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    fig.subplots_adjust(bottom=.30,top=.82,right=.92,wspace=.12)
    cax=fig.add_axes([.94,.34,.01,.4]);fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,vmax),cmap='viridis'),cax=cax,label='Patient-mean log1p(CP10K)')
    fig.suptitle('15-gene panel: preliminary three-cancer cellular localization',fontsize=17)
    handles=[axes[0].scatter([],[],s=8+160*v,color='.5',label=f'{v:.0%}') for v in [0,.25,.5,1]]
    fig.legend(handles=handles,title='Patient-mean fraction detected',loc='lower center',ncol=4,bbox_to_anchor=(.5,.06))
    fig.text(.5,.025,'Tumor tissue, not confirmed malignant cells. Patients equally weighted; >=20 cells per group. x = unavailable. Annotation methods differ.',ha='center',fontsize=10)
    fig.savefig(D/'three_cancer_15gene_localization.png',dpi=180);fig.savefig(D/'three_cancer_15gene_localization.svg');plt.close(fig)
    report={'status':'preliminary localization complete; not final cell annotation',
      'samples':len(statuses),'summary':pd.DataFrame(statuses).groupby('accession')[['source_cells','QC_cells','marker_accepted_cells']].sum().to_dict('index'),
      'limitations':['Broad canonical-marker labels without author label validation in GC/PAAD','No doublet removal or ambient RNA correction; ambiguous labels retained',
        'No CNV or malignancy confirmation for GC/PAAD','No cross-cancer differential tests; measurement and annotation methods differ',
        'No frozen survival model applied to cells','PAAD 11A/11B collapsed as same patient per GEO description'],
      'next':'Verify clustering and marker annotation; only then use GC/PAAD for perturbation.'}
    (D/'status.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2),flush=True)


def main():
    protocol={'QC':'500<=genes<6000, UMI>=500, mt_fraction<=0.2; source counts nonnegative integer checked',
      'markers':MARKERS,'classifier':'mean log1p(CP10K) per four marker set; >=2 detected markers; score>=0.5; top-second margin>=0.25; otherwise Uncertain',
      'excluded_from_annotation':GENES,'group_unit':'patient; 11A/B same patient, labels preliminary','peritoneal_samples':'kept in raw archive, not primary-tumor localization'}
    (D/'protocol.json').write_text(json.dumps(protocol,indent=2))
    for generator in [paad_samples,gc_samples]:
        for data in generator():
            acc,sample=data[:2];prefix=D/f'{acc}_{sample.replace(".csv","")}'
            if Path(str(prefix)+'_status.json').exists():continue
            process(*data);gc.collect()
    summary()


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
