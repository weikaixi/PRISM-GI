"""CRC single-cell pilot: full-transcriptome QC and donor-balanced gene localization.

Uses author-filtered UMI counts and author annotations. No survival model inference.
"""
from pathlib import Path
import gzip, hashlib, json, sys, time, importlib.metadata
import numpy as np
import pandas as pd
from scipy import sparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import anndata as ad

sys.stdout.reconfigure(encoding='utf-8')
B = Path(__file__).resolve().parents[3]
O = B / 'outputs/single_cell_virtual_v1'
GENES = ['RNF43','SERPINE1','CTLA4','MUC1','DLAT','MET','CXCL1','MUC2','PDK4','INHBB','IL10','CLCA1','CA9','P4HA1','TIMP1']
MARKERS = ['EPCAM','KRT8','KRT18','KRT19','CD3D','CD3E','TRAC','MS4A1','CD79A','CD79B','LST1','TYROBP','FCER1G','TPSAB1','KIT','COL1A1','COL1A2','DCN','PECAM1','VWF']
CELLTYPES = ['Epithelial cells','Stromal cells','T cells','Myeloids','B cells','Mast cells']
EXPECTED_HASH = 'b13b6876bb25dadf54801e10286ccd124c4d2d7a013e5c3d10be802846ebae67'

def savefig(fig, folder, name):
    fig.savefig(folder / f'{name}.png', dpi=180, bbox_inches='tight')
    fig.savefig(folder / f'{name}.svg', bbox_inches='tight')
    plt.close(fig)

def build_counts(acc):
    src = O / 'source_data' / acc
    out = O / acc
    out.mkdir(exist_ok=True)
    cache = out / 'author_filtered_raw_counts.h5ad'
    if cache.exists():
        return ad.read_h5ad(cache)
    ann = pd.read_csv(next(src.glob('*annotation*.gz')), sep='\t', index_col=0)
    assert ann.index.is_unique and ann.notna().all().all()
    genes, values, indices, indptr = [], [], [], [0]
    start = time.time()
    with gzip.open(next(src.glob('*raw_UMI*.gz')), 'rt') as handle:
        cells = handle.readline().rstrip('\n').split('\t')[1:]
        assert len(cells) == len(set(cells)) and set(cells) == set(ann.index)
        for line in handle:
            gene, payload = line.rstrip('\n').split('\t', 1)
            # Parse as signed integer and verify source token count. These are raw UMI.
            vals = np.fromstring(payload, dtype=np.int32, sep='\t')
            assert len(vals) == len(cells) and np.min(vals) >= 0
            nz = np.flatnonzero(vals).astype(np.int32)
            genes.append(gene)
            indices.append(nz)
            values.append(vals[nz])
            indptr.append(indptr[-1] + len(nz))
            if len(genes) % 5000 == 0:
                print(acc, len(genes), 'genes', round(time.time()-start, 1), 'seconds', flush=True)
    assert len(genes) == len(set(genes)), 'Duplicate gene symbols must be resolved explicitly'
    x = sparse.csr_matrix((np.concatenate(values), np.concatenate(indices), np.array(indptr)), shape=(len(genes),len(cells))).T.tocsr()
    a = ad.AnnData(x, obs=ann.loc[cells].copy(), var=pd.DataFrame(index=pd.Index(genes, name='gene_symbol')))
    a.obs.index.name = 'cell_id'
    a.uns['source'] = f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}'
    a.uns['matrix_scale'] = 'Author-filtered cells, raw non-negative integer UMI counts'
    a.write_h5ad(cache, compression='gzip')
    print(acc, a.shape, 'sparse raw counts saved', flush=True)
    return a

def group_summary(a, mask, columns, panel):
    """Each record = patient x class x annotated cell population x gene."""
    obs = a.obs.loc[mask].copy()
    ix = np.flatnonzero(mask)
    raw = a.X[ix, :][:, a.var_names.get_indexer(panel)].toarray().astype(float)
    lognorm = np.log1p(raw / obs.total_UMI.to_numpy()[:,None] * 10000)
    rows = []
    for key, loc in obs.groupby(columns, observed=True, sort=True).indices.items():
        if not isinstance(key, tuple): key = (key,)
        base = dict(zip(columns, key))
        for j, gene in enumerate(panel):
            rows.append(dict(**base, gene=gene, n_cells=len(loc), eligible_20_cells=len(loc)>=20,
                             detected_cells=int((raw[loc,j]>0).sum()), fraction_detected=float((raw[loc,j]>0).mean()),
                             mean_log1p_CP10K=float(lognorm[loc,j].mean()), raw_UMI_sum=int(raw[loc,j].sum()),
                             group_library_UMI=int(obs.total_UMI.iloc[loc].sum())))
    return pd.DataFrame(rows)

def dotplot(summary, panel, classes, out, name, title):
    # Patient is the unit: arithmetic average of within-patient summary statistics.
    s = summary[summary.eligible_20_cells].groupby(['Class','Cell_type','gene'], observed=True).agg(
        mean_log1p_CP10K=('mean_log1p_CP10K','mean'), fraction_detected=('fraction_detected','mean'), patients=('Patient','nunique')).reset_index()
    fig, axs = plt.subplots(1,len(classes),figsize=(6.7*len(classes),6.8),squeeze=False, sharey=True)
    vmax = max(s.mean_log1p_CP10K.max(), .1)
    for ax, cls in zip(axs[0],classes):
        q = s[s.Class==cls].set_index(['Cell_type','gene'])
        for j, ct in enumerate(CELLTYPES):
            for i, gene in enumerate(panel):
                if (ct,gene) not in q.index:
                    ax.plot(i,j,marker='x',color='.75',ms=4)
                    continue
                r=q.loc[(ct,gene)]
                ax.scatter(i,j,s=8+180*r.fraction_detected,c=[r.mean_log1p_CP10K],cmap='viridis',vmin=0,vmax=vmax,edgecolors='.5',linewidths=.3)
        ax.set_xticks(range(len(panel)),panel,rotation=65,ha='right',fontsize=9)
        ax.set_yticks(range(len(CELLTYPES)),CELLTYPES)
        ax.set_title(cls)
        ax.set_xlim(-.7,len(panel)-.3); ax.set_ylim(len(CELLTYPES)-.4,-.7)
        ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    fig.suptitle(title, y=.98)
    fig.subplots_adjust(bottom=.3,top=.86,wspace=.08,right=.9)
    cax=fig.add_axes([.92,.35,.012,.42])
    fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(0,vmax),cmap='viridis'),cax=cax,label='Patient-mean log1p(CP10K)')
    handles=[axs[0,0].scatter([],[],s=8+180*p,color='.6',label=f'{p:.0%}') for p in [0,.25,.5,1]]
    fig.legend(handles=handles,title='Patient-mean fraction detected',loc='lower center',ncol=4,bbox_to_anchor=(.48,.045))
    fig.text(.5,.015,'Author labels; patients weighted equally; groups require >=20 cells. x = missing gene or no eligible patient group.',ha='center',fontsize=9)
    savefig(fig,out,name)
    return s

def analyze(acc):
    a=build_counts(acc)
    out=O/acc; figs=out/'figures';figs.mkdir(exist_ok=True)
    a.obs['total_UMI']=np.asarray(a.X.sum(axis=1)).ravel()
    a.obs['detected_genes']=a.X.getnnz(axis=1)
    mt=a.var_names.str.startswith('MT-')
    assert mt.sum() > 0, 'No mitochondrial gene symbols found'
    a.obs['mt_fraction']=np.asarray(a.X[:,mt].sum(axis=1)).ravel()/a.obs.total_UMI
    a.obs['qc_sensitivity_pass']=(a.obs.detected_genes>=200)&(a.obs.total_UMI>=500)&(a.obs.mt_fraction<=.2)
    for metric in ['total_UMI','detected_genes']:
        group=a.obs.groupby('Sample',observed=True)[metric]
        med=group.transform('median')
        mad=group.transform(lambda z: np.median(np.abs(z-np.median(z))))
        a.obs[f'{metric}_high_MAD_flag']=(a.obs[metric]>med+3*mad)&(mad>0)
    a.obs.to_csv(out/'cell_annotation_and_QC.csv.gz')
    sample=a.obs.groupby(['Patient','Class','Sample'],observed=True).agg(cells=('Cell_type','size'),
        qc_sensitivity_cells=('qc_sensitivity_pass','sum'),median_UMI=('total_UMI','median'),median_genes=('detected_genes','median'),median_mt_fraction=('mt_fraction','median')).reset_index()
    sample.to_csv(out/'sample_QC_summary.csv',index=False)
    composition=a.obs.groupby(['Patient','Class','Sample','Cell_type','Cell_subtype'],observed=True).size().rename('cells').reset_index()
    composition.to_csv(out/'cell_composition_by_patient.csv',index=False)
    classes=[x for x in ['Normal','Tumor','Border'] if x in set(a.obs.Class)]
    panel=[g for g in GENES if g in a.var_names]
    counts=a.X[:,a.var_names.get_indexer(panel)].toarray()
    coverage=pd.DataFrame({'gene':GENES,'present_in_matrix':[g in a.var_names for g in GENES]})
    coverage['detected_cells']=[int((counts[:,panel.index(g)]>0).sum()) if g in panel else np.nan for g in GENES]
    coverage['fraction_detected']=coverage.detected_cells/a.n_obs
    coverage.to_csv(out/'15gene_matrix_coverage.csv',index=False)
    if len(panel)!=15:
        print(acc,'Missing source rows (NOT zero expression):',[g for g in GENES if g not in panel],flush=True)
    outputs={}
    for label,mask in [('author_QC',np.ones(a.n_obs,dtype=bool)),('sensitivity_QC',a.obs.qc_sensitivity_pass.to_numpy())]:
        s=group_summary(a,mask,['Patient','Class','Cell_type'],panel)
        s.to_csv(out/f'patient_celltype_15gene_{label}.csv',index=False)
        balanced=dotplot(s,GENES,classes,figs,f'15gene_celltype_{label}',f'{acc}: 15-gene panel localization ({label}; {len(panel)}/15 available)')
        balanced.to_csv(out/f'patient_balanced_celltype_15gene_{label}.csv',index=False)
        outputs[label]=balanced
    sub=group_summary(a,np.ones(a.n_obs,dtype=bool),['Patient','Class','Cell_type','Cell_subtype'],panel)
    sub.to_csv(out/'patient_subtype_15gene_author_QC.csv',index=False)
    sub[sub.eligible_20_cells].groupby(['Class','Cell_type','Cell_subtype','gene'],observed=True).agg(
        mean_log1p_CP10K=('mean_log1p_CP10K','mean'),fraction_detected=('fraction_detected','mean'),patients=('Patient','nunique')).reset_index().to_csv(out/'patient_balanced_subtype_15gene.csv',index=False)
    marker_panel=[g for g in MARKERS if g in a.var_names]
    marker=group_summary(a,np.ones(a.n_obs,dtype=bool),['Patient','Class','Cell_type'],marker_panel)
    dotplot(marker,marker_panel,classes,figs,'author_label_marker_audit',f'{acc}: canonical marker audit (author labels)')
    marker.to_csv(out/'patient_celltype_marker_audit.csv',index=False)
    fig,axs=plt.subplots(1,3,figsize=(13,4))
    for ax,col,label in zip(axs,['total_UMI','detected_genes','mt_fraction'],['UMI per cell','Detected genes per cell','Mitochondrial UMI fraction']):
        for cls in classes:
            vals=a.obs.loc[a.obs.Class==cls,col]
            if col!='mt_fraction': vals=np.log10(vals.clip(lower=1))
            ax.hist(vals,bins=60,histtype='step',density=True,label=cls)
        ax.set_xlabel(('log10 ' if col!='mt_fraction' else '')+label)
        ax.set_ylabel('Density')
    axs[0].legend();fig.suptitle(acc+': author-filtered cell QC');fig.tight_layout();savefig(fig,figs,'QC_distributions')
    # Patient x tissue x celltype full-transcriptome counts for later state/DE work.
    group_cols=['Patient','Class','Cell_type']
    keys=a.obs[group_cols].astype(str).agg('|'.join,axis=1)
    codes,unique=pd.factorize(keys,sort=True)
    indicator=sparse.csr_matrix((np.ones(a.n_obs,dtype=np.int64),(codes,np.arange(a.n_obs))),shape=(len(unique),a.n_obs))
    pb=indicator@a.X.astype(np.int64)
    pbobs=pd.DataFrame([k.split('|') for k in unique],columns=group_cols,index=unique)
    pbobs['cells']=np.bincount(codes);pbobs['eligible_20_cells']=pbobs.cells>=20
    pba=ad.AnnData(pb,obs=pbobs,var=a.var.copy());pba.uns['note']='Raw summed UMI; patient x tissue class x author cell type. Not normalized or batch corrected.'
    pba.write_h5ad(out/'patient_celltype_pseudobulk_raw.h5ad',compression='gzip')
    # Separate annotated epithelial counts preserve raw data for future CNV/tokenization.
    epi=a[a.obs.Cell_type=='Epithelial cells'].copy()
    epi.uns['malignancy_warning']='Tumor-origin epithelium is not independently confirmed malignant. No CNV called in this pilot.'
    epi.write_h5ad(out/'epithelial_raw_counts_with_QC.h5ad',compression='gzip')
    audit={'accession':acc,'cells':a.n_obs,'genes':a.n_vars,'patients':a.obs.Patient.nunique(),'samples':a.obs.Sample.nunique(),
           'classes':{str(k):int(v) for k,v in a.obs.Class.value_counts().items()},'qc_sensitivity_cells':int(a.obs.qc_sensitivity_pass.sum()),
           'mitochondrial_genes':int(mt.sum()),'panel_present':len(panel),'epithelial_cells':epi.n_obs,'nnz':int(a.X.nnz),
           'author_labels_used':True,'independent_CN_validation_done':False,'ambient_RNA_correction_done':False,
           'doublet_detection':'Author filtering relied upon; MAD flags are sensitivity indicators only'}
    (out/'audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps(audit),flush=True)
    return audit

if __name__=='__main__':
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    model=B/'outputs/final_model_deepsurv_v1/model.pt'
    before=hashlib.file_digest(model.open('rb'),'sha256').hexdigest()
    assert before==EXPECTED_HASH
    audits=[analyze(acc) for acc in ['GSE132465','GSE144735']]
    after=hashlib.file_digest(model.open('rb'),'sha256').hexdigest()
    assert before==after
    versions={m:importlib.metadata.version(m) for m in ['numpy','pandas','scipy','matplotlib','anndata','scanpy']}
    (O/'runtime_versions.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
    (O/'CRC_pilot_audit.json').write_text(json.dumps({'cohorts':audits,'frozen_model_sha256':after},indent=2),encoding='utf-8')
