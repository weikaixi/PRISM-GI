"""Frozen LOCAL LEGACY DeepSurv transfer; not the formal three-domain model.

Raw counts are retained for audit. Source-missing features use the legacy
median-rank rule, not zero-count imputation. No fitting or outcome selection.
"""
from pathlib import Path
import csv, gzip, tarfile, json, hashlib, sys, gc, itertools
import numpy as np
import pandas as pd
import anndata as ad
import torch
from torch import nn
from scipy.stats import spearmanr, wilcoxon, false_discovery_control
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT/'outputs/single_cell_virtual_v1'
OLD = BASE/'panel_signature_tsne_v1'
OUT = BASE/'legacy_model_single_cell_v1'
WEIGHTS = ROOT/'outputs/final_model_deepsurv_v1/model.pt'
EXPECTED = 'b13b6876bb25dadf54801e10286ccd124c4d2d7a013e5c3d10be802846ebae67'
ACCS = ['GSE132465', 'GSE183904', 'GSE155698']
NAMES = dict(zip(ACCS, ['CRC', 'GC', 'PAAD']))
TYPES = ['Epithelial', 'Stromal', 'T/NK', 'Myeloid', 'B/Plasma', 'Mast', 'Uncertain']
COLORS = dict(zip(TYPES, ['#d96845','#a475b8','#4e9c71','#d1a638','#4d8cbd','#db6c9b','#b8b8b8']))
SEED = 20260918
sys.stdout.reconfigure(encoding='utf-8')
ad.settings.allow_write_nullable_strings = True
torch.set_num_threads(2)
torch.use_deterministic_algorithms(True)


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


class Frozen:
    def __init__(self):
        assert hashlib.sha256(WEIGHTS.read_bytes()).hexdigest() == EXPECTED
        a = torch.load(WEIGHTS, weights_only=True, map_location='cpu')
        self.a = a
        self.pool, self.genes = a['rank_pool'], a['genes']
        self.ix = [self.pool.index(g) for g in self.genes]
        self.mu, self.sd = np.array(a['mu']), np.array(a['sd'])
        self.glob, self.lam = np.array(a['train_global_158']), a['lambda']
        p = a['config']['params']
        self.net = nn.Sequential(nn.Linear(15,p['hidden']),nn.Tanh(),nn.Dropout(p['dropout']),nn.Linear(p['hidden'],1,bias=False))
        self.net.load_state_dict(a['state_dict'])
        self.net.eval()

    def rank(self, counts):
        # pandas excludes unavailable source genes (NaN), but includes measured
        # zeros as tied observations. Matches the serialized legacy convention.
        return pd.DataFrame(counts, columns=self.pool).rank(axis=1, method='average', pct=True).fillna(.5).to_numpy()

    def predict(self, ranks, center=None):
        if center is None:
            center = ranks.mean(0)
        adjusted = ranks - self.lam*(center-self.glob)
        z = (adjusted[:,self.ix]-self.mu)/self.sd
        with torch.no_grad():
            scores = self.net(torch.tensor(z,dtype=torch.float32)).numpy().ravel()
        assert np.isfinite(scores).all()
        return scores, z, center


def model_validation(m):
    """Reproduce a stored GEO cohort and independently evaluate the network."""
    acc = 'GSE17536'
    expr = pd.read_csv(ROOT/f'work/rebuild/data/processed/geo_os_expression/{acc}_gene_expression.tsv.gz', sep='\t', index_col=0).T
    clinical = pd.read_csv(ROOT/'work/rebuild/data/processed/geo_os.tsv', sep='\t')
    clinical = clinical.loc[clinical.cohort.eq(acc)].set_index('gsm')
    ids = expr.index.intersection(clinical.index, sort=False)
    ranks = m.rank(expr.loc[ids].reindex(columns=m.pool).to_numpy())
    score,z,_ = m.predict(ranks)
    saved = pd.read_csv(ROOT/'outputs/final_model_deepsurv_v1/geo_predictions.csv').set_index('sample')
    expected = saved.loc[[acc+':'+s for s in ids], 'risk'].to_numpy()
    np.testing.assert_allclose(score, expected, atol=2e-6, rtol=2e-6)
    w = m.a['state_dict']
    independent = np.tanh(z@w['0.weight'].numpy().T+w['0.bias'].numpy())@w['3.weight'].numpy().T
    np.testing.assert_allclose(score, independent.ravel(), atol=2e-6, rtol=2e-6)
    # Reconstruct the TCGA input domain to audit extrapolation, never fit a model.
    pieces, domains = [], []
    for d in ['colorectal','pancreatic','gastric']:
        p = ROOT/'work/rebuild/data/processed/training_domains'
        e = pd.read_csv(p/f'{d}_expression_primary.tsv.gz',sep='\t',index_col=0).T
        c = pd.read_csv(p/f'{d}_clinical_primary.tsv',sep='\t').set_index('patient_id')
        e = e.loc[e.index.intersection(c.index,sort=False)].reindex(columns=m.pool)
        assert e.notna().all().all()
        pieces.append(m.rank(e.to_numpy()))
        domains.extend([d]*len(e))
    x = np.vstack(pieces); domains = np.array(domains)
    np.testing.assert_allclose(x.mean(0),m.glob,atol=1e-12)
    adj = x.copy()
    for d in np.unique(domains):
        q = domains==d
        adj[q] -= m.lam*(x[q].mean(0)-m.glob)
    np.testing.assert_allclose(adj[:,m.ix].mean(0),m.mu,atol=1e-12)
    np.testing.assert_allclose(adj[:,m.ix].std(0),m.sd,atol=1e-12)
    trainz = (adj[:,m.ix]-m.mu)/m.sd
    m.low, m.high = trainz.min(0), trainz.max(0)
    res = dict(frozen_model_sha256=EXPECTED, unchanged=True, geo_cohort=acc,
               geo_samples=len(ids), geo_prediction_max_error=float(abs(score-expected).max()),
               independent_numpy_max_error=float(abs(score-independent.ravel()).max()),
               tcga_samples=len(x), training_scaling_reproduced=True)
    dump(OUT/'model_validation.json',res)
    print('Frozen model validated:',res,flush=True)


def save_counts(acc,sample,counts,cells,genes,m,obs):
    folder = OUT/acc/'inputs'; folder.mkdir(parents=True,exist_ok=True)
    tag = sample.replace('.csv','')
    target = folder/f'{tag}_counts158.h5ad'
    if target.exists():
        return
    assert pd.Index(cells).is_unique and pd.Index(genes).is_unique
    valid = obs.index.intersection(cells,sort=False)
    assert len(valid)>0
    ri = pd.Index(cells).get_indexer(valid)
    gi = pd.Index(genes).get_indexer(m.pool)
    arr = np.full((len(valid),158),np.nan,dtype=np.float32)
    present = gi>=0
    part = counts[ri][:,gi[present]]
    arr[:,present] = part.toarray() if hasattr(part,'toarray') else part
    assert np.isfinite(arr[:,present]).all() and (arr[:,present]>=0).all()
    assert (arr[:,present]==np.floor(arr[:,present])).all()
    # Compare independent original display caches to the new source extraction.
    cache = OLD/acc/f'{tag}_display_raw.h5ad'
    ref = ad.read_h5ad(cache,backed='r')
    checkids = ref.obs_names[:min(10,len(ref))]
    assert set(checkids).issubset(valid)
    refgi = ref.var_names.get_indexer(np.array(m.pool)[present]); assert (refgi>=0).all()
    original = ref[:len(checkids),:].to_memory().X[:,refgi]
    original = original.toarray() if hasattr(original,'toarray') else original
    np.testing.assert_array_equal(arr[valid.get_indexer(checkids)][:,present],original)
    ref.file.close()
    a = ad.AnnData(arr, obs=obs.loc[valid].copy(), var=pd.DataFrame(index=m.pool))
    a.uns['missing_source_genes'] = list(np.array(m.pool)[~present])
    a.uns['raw_counts_note'] = 'NaN = absent source gene; zero = measured zero; no imputation in this raw cache.'
    a.write_h5ad(target,compression='gzip')
    print('Counts cached',acc,sample,len(a),'missing',a.uns['missing_source_genes'],flush=True)


def extract(acc,m):
    obs = pd.read_csv(OLD/acc/'all_tumor_cell_scores.csv.gz',index_col=0)
    folder = OUT/acc/'inputs'; folder.mkdir(parents=True,exist_ok=True)
    if acc=='GSE132465':
        if not (folder/'tumor_all_counts158.h5ad').exists():
            a = ad.read_h5ad(BASE/acc/'author_filtered_raw_counts.h5ad')
            save_counts(acc,'tumor_all',a.X,a.obs_names,a.var_names,m,obs)
            del a;gc.collect()
    elif acc=='GSE183904':
        mapping = pd.read_csv(BASE/'GSE183904_patient_sample_mapping.csv').set_index('sample_file')
        with tarfile.open(BASE/'source_data/GSE183904/GSE183904_RAW.tar') as archive:
            for member in archive.getmembers():
                if not member.isfile() or not member.name.endswith('.csv.gz'):continue
                sample = member.name.split('_',1)[1].removesuffix('.gz')
                if mapping.loc[sample,'tissue_class']!='Primary_Tumor':continue
                tag = sample.replace('.csv','')
                if (folder/f'{tag}_counts158.h5ad').exists():continue
                genes,values = [],[]
                with gzip.open(archive.extractfile(member),'rt') as f:
                    cells = next(csv.reader([f.readline()]))[1:]
                    # Decode only relevant rows, while scanning every row so
                    # source-absent symbols remain distinct from count zero.
                    for line in f:
                        gene,payload = line.rstrip('\n').split(',',1)
                        gene = gene.strip('"')
                        if gene not in m.pool:continue
                        vals = np.fromstring(payload,sep=',',dtype=np.float64)
                        assert len(vals)==len(cells)
                        genes.append(gene);values.append(vals)
                frame = pd.DataFrame(np.array(values),index=genes).groupby(level=0,sort=False).sum()
                save_counts(acc,sample,frame.to_numpy().T,[sample+'|'+c for c in cells],frame.index,m,obs)
    elif not all((folder/(str(s).replace('.csv','')+'_counts158.h5ad')).exists() for s in obs['sample'].unique()):
        from extend_three_cancer_localization import paad_samples
        for _,sample,patient,tissue,raw,genes,cells in paad_samples():
            if tissue!='Primary_Tumor':continue
            save_counts(acc,sample,raw,[sample+'|'+c for c in cells],genes,m,obs)
            del raw;gc.collect()
    parts = [ad.read_h5ad(p) for p in sorted(folder.glob('*_counts158.h5ad'))]
    a = ad.concat(parts,join='outer',merge='same')
    assert a.obs_names.is_unique and set(a.obs_names)==set(obs.index)
    a = a[obs.index,m.pool].copy();a.obs = obs.copy()
    return a


def audit_inputs(z,m):
    return pd.DataFrame(dict(max_abs_training_z=np.abs(z).max(1),
        features_outside_training_range=((z<m.low)|(z>m.high)).sum(1),
        features_abs_z_gt3=(np.abs(z)>3).sum(1)))


def summarize_and_test(acc,patient):
    good = patient.loc[patient.cells>=20].copy()
    scores = ['mean_cell_legacy_score','pseudobulk_legacy_score']
    summary = good.groupby('cell_type',observed=True).agg(patients=('patient','nunique'),
        cells=('cells','sum'),mean_cell_legacy_score=('mean_cell_legacy_score','mean'),
        pseudobulk_legacy_score=('pseudobulk_legacy_score','mean')).reset_index()
    summary['accession'] = acc
    rows=[]
    for score in scores:
        wide = good.pivot(index='patient',columns='cell_type',values=score)
        for x,y in itertools.combinations([t for t in TYPES if t!='Uncertain' and t in wide],2):
            q=wide[[x,y]].dropna();dif=q[x]-q[y]
            p=np.nan if len(q)<5 else (1. if (dif==0).all() else float(wilcoxon(dif,method='auto').pvalue))
            rows.append(dict(accession=acc,score=score,cell_type_a=x,cell_type_b=y,paired_patients=len(q),
                median_paired_difference=float(dif.median()) if len(q) else np.nan,p_value=p))
    tests=pd.DataFrame(rows);tests['FDR']=np.nan;valid=tests.p_value.notna()
    tests.loc[valid,'FDR']=false_discovery_control(tests.loc[valid,'p_value'])
    summary.to_csv(OUT/acc/'patient_equal_celltype_summary.csv',index=False)
    tests.to_csv(OUT/acc/'paired_celltype_tests.csv',index=False)
    return summary,tests


def score_cohort(acc,m):
    a=extract(acc,m);counts=np.asarray(a.X);obs=a.obs.copy()
    ranks=m.rank(counts);score,z,center=m.predict(ranks)
    # Accumulate patient summaries in float64; the network itself remains the
    # original float32 inference implementation.
    obs['legacy_model_score']=score.astype(np.float64)
    obs['rankpool_genes_detected']=np.sum(counts>0,axis=1)
    obs['panel_genes_detected']=np.sum(counts[:,m.ix]>0,axis=1)
    obs['missing_rankpool_genes']=np.sum(np.isnan(counts),axis=1)
    obs['missing_panel_genes']=np.sum(np.isnan(counts[:,m.ix]),axis=1)
    for col,v in audit_inputs(z,m).items():obs[col]=v.to_numpy()
    # Pseudobulk = raw UMI sums per patient x cell type, then ranks/model;
    # it is NOT mean(single-cell prediction) for this nonlinear network.
    pbcounts=[];rows=[];cor=[]
    for (patient,ct),idx in obs.groupby(['patient','cell_type'],observed=True).indices.items():
        part=obs.iloc[idx]
        absent=np.isnan(counts[idx]).all(0)
        assert (np.isnan(counts[idx]).all(0)==np.isnan(counts[idx]).any(0)).all(), 'Mixed source coverage within patient/cell type'
        summed=np.nansum(counts[idx].astype(np.float64),axis=0);summed[absent]=np.nan
        pbcounts.append(summed)
        rows.append(dict(accession=acc,patient=patient,cell_type=ct,cells=len(idx),eligible=len(idx)>=20,
            mean_cell_legacy_score=float(part.legacy_model_score.mean()),
            median_cell_legacy_score=float(part.legacy_model_score.median()),
            panel14_UCell=float(part.panel14_UCell.mean()),
            panel15_UCell=float(part.panel15_UCell.mean()),
            median_detected_panel_genes=float(part.panel_genes_detected.median()),
            fraction_cells_outside_training_range=float((part.features_outside_training_range>0).mean())))
        if len(part)>=30:
            for cov in ['panel14_UCell','panel15_UCell','total_UMI','detected_genes','rankpool_genes_detected','panel_genes_detected']:
                if part[cov].notna().all() and part[cov].nunique()>1 and part.legacy_model_score.nunique()>1:
                    cor.append(dict(accession=acc,patient=patient,cell_type=ct,cells=len(part),covariate=cov,
                        rho=float(spearmanr(part.legacy_model_score,part[cov]).statistic)))
    patient=pd.DataFrame(rows);pbc=np.array(pbcounts);pbr=m.rank(pbc)
    eligible=patient.eligible.to_numpy()
    # One common mean across eligible pseudobulk rows of this cohort, never
    # center each cell type separately, which would erase the comparison.
    pbs,pbz,pbcenter=m.predict(pbr,center=pbr[eligible].mean(0))
    patient['pseudobulk_legacy_score']=pbs.astype(np.float64)
    patient['pb_features_outside_training_range']=audit_inputs(pbz,m).features_outside_training_range
    patient.to_csv(OUT/acc/'patient_celltype_scores.csv',index=False)
    obs.index.name='cell_id';obs.to_csv(OUT/acc/'all_cell_scores.csv.gz')
    pd.DataFrame(cor).to_csv(OUT/acc/'within_patient_celltype_correlations.csv',index=False)
    pb=ad.AnnData(pbc,obs=patient.set_index(patient.patient.astype(str)+'|'+patient.cell_type.astype(str)),var=pd.DataFrame(index=m.pool))
    pb.write_h5ad(OUT/acc/'patient_celltype_raw_pseudobulk158.h5ad',compression='gzip')
    coverage=[]
    for sample,idx in obs.groupby('sample',observed=True).indices.items():
        missing=np.isnan(counts[idx]).all(0);assert np.array_equal(missing,np.isnan(counts[idx]).any(0))
        coverage.append(dict(sample=str(sample),cells=len(idx),missing_rankpool=list(np.array(m.pool)[missing]),
                             missing_panel=[g for g in m.genes if missing[m.pool.index(g)]]))
    dump(OUT/acc/'coverage_and_centers.json',dict(coverage=coverage,cell_center=center.tolist(),pseudobulk_center=pbcenter.tolist()))
    # The CRC source is missing a selected predictor. This is an input
    # sensitivity, not recovery of the gene or formal uncertainty intervals.
    sensitivity=[]
    if obs.missing_panel_genes.max()>0:
        assert acc=='GSE132465'
        j=m.pool.index('MUC2')
        for value in [0.,1.]:
            r=ranks.copy();r[:,j]=value;s,_,_=m.predict(r)
            col=f'MUC2_rank_{int(value)}_score';obs[col]=s.astype(np.float64)
            pr=pbr.copy();pr[:,j]=value;ps,_,_=m.predict(pr,center=pr[eligible].mean(0))
            patient[col+'_pseudobulk']=ps.astype(np.float64)
            patient[col+'_cellmean']=[float(s[idx].astype(np.float64).mean()) for idx in obs.groupby(['patient','cell_type'],observed=True).indices.values()]
            sensitivity.append(dict(MUC2_assumed_rank=value,cell_score_spearman=float(spearmanr(score,s).statistic),
                median_absolute_cell_score_change=float(np.median(abs(score-s))),
                pseudobulk_score_spearman=float(spearmanr(pbs[eligible],ps[eligible]).statistic)))
        obs.to_csv(OUT/acc/'all_cell_scores.csv.gz')
        patient.to_csv(OUT/acc/'patient_celltype_scores.csv',index=False)
        dump(OUT/acc/'MUC2_missing_input_sensitivity.json',sensitivity)
    summary,tests=summarize_and_test(acc,patient)
    coord=pd.read_csv(OLD/acc/'tsne_coordinates_and_scores.csv.gz',index_col=0)
    assert set(coord.index).issubset(obs.index)
    for col in ['legacy_model_score','max_abs_training_z','features_outside_training_range','missing_panel_genes']:
        coord[col]=obs.loc[coord.index,col]
    coord.to_csv(OUT/acc/'tsne_coordinates_and_model_scores.csv.gz')
    status=dict(completed=True,accession=acc,cells=len(obs),patients=obs.patient.nunique(),display_cells=len(coord),
        eligible_patient_celltypes=int(eligible.sum()),missing_panel_genes=sorted(set(sum([r['missing_panel'] for r in coverage],[]))),
        median_detected_panel_genes=float(obs.panel_genes_detected.median()),
        cells_any_feature_outside_training_range=float((obs.features_outside_training_range>0).mean()),
        eligible_pseudobulk_any_feature_outside_training_range=float((patient.loc[eligible,'pb_features_outside_training_range']>0).mean()),
        score_range=[float(score.min()),float(score.max())],frozen_model_sha256=EXPECTED)
    dump(OUT/acc/'status.json',status);print('Scored:',status,flush=True)
    return status


def savefig(fig,name):
    for ext in ['png','svg']:fig.savefig(OUT/f'{name}.{ext}',dpi=180,bbox_inches='tight')
    plt.close(fig)


def report():
    coords={a:pd.read_csv(OUT/a/'tsne_coordinates_and_model_scores.csv.gz',index_col=0) for a in ACCS}
    patients={a:pd.read_csv(OUT/a/'patient_celltype_scores.csv') for a in ACCS}
    statuses=[json.loads((OUT/a/'status.json').read_text()) for a in ACCS]
    summaries=pd.concat([pd.read_csv(OUT/a/'patient_equal_celltype_summary.csv') for a in ACCS])
    summaries.to_csv(OUT/'all_patient_equal_celltype_summary.csv',index=False)
    fig,axes=plt.subplots(3,3,figsize=(16,13))
    for i,acc in enumerate(ACCS):
        c=coords[acc];xy=c[['tSNE1','tSNE2']].to_numpy()
        for ct in TYPES:
            q=c.cell_type.eq(ct).to_numpy()
            if q.any():axes[i,0].scatter(*xy[q].T,s=3,c=COLORS[ct],label=ct,alpha=.75,rasterized=True)
        axes[i,0].set_title(f'{NAMES[acc]} | cell types')
        for col,score,title in [(1,'panel14_UCell','14-gene UCell (unsigned)'),(2,'legacy_model_score','Frozen legacy model score')]:
            order=np.argsort(c[score].to_numpy())
            im=axes[i,col].scatter(*xy[order].T,c=c[score].to_numpy()[order],s=3,cmap='viridis',rasterized=True)
            fig.colorbar(im,ax=axes[i,col],shrink=.72,label='UCell' if col==1 else 'Model output (not OS probability)')
            axes[i,col].set_title(f'{NAMES[acc]} | {title}'+('\nMUC2 rank imputed as 0.5' if col==2 and acc=='GSE132465' else ''))
        for ax in axes[i]:ax.set_xticks([]);ax.set_yticks([]);ax.set_xlabel('t-SNE 1');ax.set_ylabel('t-SNE 2')
    handles,labels=axes[1,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=7,markerscale=3)
    fig.suptitle('LOCAL LEGACY DeepSurv transfer | fixed weights, lambda = 0.5\nSame existing t-SNE coordinates; NOT the formal three-domain projection model',fontsize=14)
    fig.tight_layout(rect=[0,.04,1,.94]);savefig(fig,'three_cancer_legacy_model_tSNE')
    fig,axes=plt.subplots(2,3,figsize=(16,8.5))
    for j,acc in enumerate(ACCS):
        p=patients[acc];p=p[p.cells>=20];cts=[t for t in TYPES if t in p.cell_type.unique()]
        for i,score in enumerate(['mean_cell_legacy_score','pseudobulk_legacy_score']):
            ax=axes[i,j];rng=np.random.default_rng(SEED)
            for k,ct in enumerate(cts):
                v=p.loc[p.cell_type.eq(ct),score].to_numpy()
                ax.scatter(k+rng.uniform(-.18,.18,len(v)),v,color=COLORS[ct],s=20,alpha=.75)
                ax.plot([k-.25,k+.25],[v.mean()]*2,c='black',lw=2)
            ax.set_xticks(range(len(cts)),cts,rotation=35,ha='right')
            ax.set_ylabel('Legacy model output');ax.set_title(f'{NAMES[acc]} | '+('mean single-cell score' if i==0 else 'raw-sum pseudobulk score'))
    fig.suptitle('Each dot = patient/cell type with >=20 cells; black bar = equal-patient mean\nDifferent scoring units/centers: do not compare absolute scales between rows or cancers',fontsize=12)
    fig.tight_layout(rect=[0,0,1,.92]);savefig(fig,'patient_level_legacy_model_scores')
    text=['# 本地旧版模型的单细胞衍生评分','',
        '本次由用户明确确认使用本机旧版模型开展探索。不是另一台电脑的三域子空间投影正式模型。',
        '固定15基因、TIMP1保留、λ=0.5、DeepSurv权重及训练集标准化参数。没有重训、筛基因或调参。','',
        '## 方法','',
        '原始UMI在源矩阵实际存在的158基因池内做样本内升序百分位排名，零计数并列取平均。源矩阵缺失的基因才按旧版规则赋排名0.5；不是补表达量0。',
        '排名矩阵X按 X−0.5×(本队列平均排名−TCGA训练集平均排名) 校正，再提取固定顺序的15基因，使用已保存的训练均值和总体标准差，送入15→16(Tanh)→1网络。Dropout在预测时关闭。',
        '所有通过之前QC的肿瘤组织细胞纳入。单细胞校正中心是每个GEO队列全体入选细胞的均值，不按细胞类型分别中心化。该转用方式依赖队列细胞组成，不是单细胞已验证的域适配方案。',
        '患者×细胞类型伪bulk先将原始计数相加再排名预测。≥20细胞的伪bulk构成该队列共同校正中心。伪bulk分数不等于单细胞分数的平均；两种分析的校正中心及单位不同，不能混用绝对值。',
        't-SNE直接复用已有坐标及展示子集，没有为了模型分数重新选择细胞或重跑降维。统计使用全部细胞，以患者×细胞类型为单位。',
        'CRC使用作者宽类注释；GC/PAAD沿用独立标记支持的初步宽类注释。上皮细胞不等同于恶性细胞，基质类也尚未在本轮细分为成纤维、内皮等亚型。',
        '配对Wilcoxon要求≥5配对患者；每队列内两种评分×所有已命名细胞类型配对共同BH校正。Uncertain保留图示，不参与配对检验。探索性分析，无单细胞OS标签，不计算OS AUC、C-index、KM或生存概率。','',
        '## 覆盖与输入外推','',
        '| 癌种 | 患者 | 全部细胞 | 展示细胞 | 每细胞检出面板基因中位数 | 存在超出训练范围特征的细胞比例 | 伪bulk比例 |',
        '|---|---:|---:|---:|---:|---:|---:|']
    for s in statuses:
        text.append(f"| {NAMES[s['accession']]} | {s['patients']} | {s['cells']} | {s['display_cells']} | {s['median_detected_panel_genes']:g} | {s['cells_any_feature_outside_training_range']:.1%} | {s['eligible_pseudobulk_any_feature_outside_training_range']:.1%} |")
    text += ['', '结直肠癌MUC2源缺失，因此该队列是含排名0.5替代的15输入模型输出，不是完整测得15基因的验证。另保存MUC2固定输入排名0/1的敏感性，不代表真实表达恢复或置信区间。PAAD部分数据还存在非面板排名背景基因缺失，逐样本列表已保存。','',
        'UMI计数排名与bulk RNA-seq/芯片测量机制不同，排序不能保证消除稀疏、测序深度或基因长度相关偏差。伪bulk减轻掉零但并不自动解决训练分布外推。','',
        '## 患者等权细胞类型汇总','',
        '| 癌种 | 细胞类型 | 患者数 | 平均单细胞模型分数 | 伪bulk模型分数 |','|---|---|---:|---:|---:|']
    for acc in ACCS:
        for r in summaries[summaries.accession.eq(acc)].sort_values('mean_cell_legacy_score',ascending=False).itertuples():
            text.append(f'| {NAMES[acc]} | {r.cell_type} | {r.patients} | {r.mean_cell_legacy_score:.4f} | {r.pseudobulk_legacy_score:.4f} |')
    text += ['', '## 解读边界','',
        '分数是固定旧版网络的连续输出。bulk中较高输出对应模型定义的较高相对风险方向，但不能据此给单个细胞赋予已验证的生存风险或说该细胞导致患者预后变差。',
        '无权重UCell衡量面板整体表达排序，带参数网络则综合基因特异性权重、非线性和标准化，因此二者分布不必一致。不得挑选更符合预期的评分版本作为主结果。',
        '不同癌种、不同比较单位的绝对分数不直接比较。不按单细胞评分中位数宣称临床高低风险，也不因评分图改变正式模型。',
        '本机模型历史开发曾使用GEO筛选配置和种子，其旧外部结果不是未参与开发的独立验证。本次不改变这一来源限制。',
        '优先报告患者级重复性、与伪bulk结果的一致性、输入缺失和训练分布外推情况。论文正式模型解释仍需正式三域模型工件。','']
    (OUT/'report.md').write_text('\n'.join(text),encoding='utf-8')
    dump(OUT/'status.json',dict(completed=True,model='local legacy mean-shift DeepSurv',formal_three_domain_model=False,
         cohorts=statuses,unchanged_model_sha256=hashlib.sha256(WEIGHTS.read_bytes()).hexdigest()))


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    m=Frozen();model_validation(m)
    dump(OUT/'protocol.json',dict(model='LOCAL LEGACY mean-shift DeepSurv, NOT formal three-domain projection',
        user_authorized=True,weights_sha256=EXPECTED,genes=m.genes,rank_pool=m.pool,lambda_fixed=m.lam,
        no_refitting=True,TIMP1_retained=True,source_missing_rank=.5,measured_zeros='average ties, not missing',
        seed_for_plot_jitter=SEED,cohort_cell_center='all QC tumor cells, cell-weighted, shared across cell types',
        pseudobulk='sum raw counts per patient/cell type; center across >=20-cell pseudobulk rows within cohort',
        score='network output, not calibrated single-cell survival risk',input_scale='raw UMI ranks, not proven equivalent to bulk expression ranks',
        tests='paired patients, >=5 pairs; BH all cell-type pairs and both score definitions per cohort',
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        aggregation_precision='float64; frozen network inference uses original float32'))
    requested=sys.argv[1:]
    rescore='--rescore' in requested
    requested=[s for s in requested if s!='--rescore']
    for acc in requested or ACCS:
        if acc=='report':continue
        if rescore or not (OUT/acc/'status.json').exists():score_cohort(acc,m)
    if all((OUT/a/'status.json').exists() for a in ACCS):report()


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
