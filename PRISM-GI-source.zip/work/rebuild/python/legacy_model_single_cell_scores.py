"""Score externally preprocessed cell/pseudobulk features; see README.md.

No raw-count ranking or domain correction. Shares the bulk Node inference engine.
"""
from pathlib import Path
import argparse
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', help='Processed CSV with sample_id, input_stage and 15 features')
    parser.add_argument('cancer', choices=['colorectal','gastric','pancreatic'])
    parser.add_argument('output', help='New CSV path')
    args = parser.parse_args()
    node = shutil.which('node')
    if not node: parser.error('Node.js >=20 is required')
    root = Path(__file__).resolve().parents[3]
    subprocess.run([node, str(root/'predict.mjs'), args.input, args.cancer, args.output], check=True)


if __name__ == '__main__': main()
