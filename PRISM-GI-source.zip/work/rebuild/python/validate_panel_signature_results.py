"""Independent aggregation, source coverage, BH and embedding consistency checks."""
import json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import anndata as ad
from scipy.stats import false_discovery_control
from score_panel_single_cells import D,GENES,O

results=[]
for acc in ['GSE132465','GSE183904','GSE155698']:
    folder=D/acc;cells=pd.read_csv(folder/'all_tumor_cell_scores.csv.gz',index_col=0)
    assert cells.index.is_unique and cells.tissue.eq('Primary_Tumor').all()
    statuses=[json.loads(p.read_text()) for p in folder.glob('*_status.json') if p.name!='analysis_status.json']
    assert len(cells)==sum(s['cells'] for s in statuses)
    if acc=='GSE132465':
        assert cells.panel15_UCell.isna().all()
        original=pd.read_csv(O/acc/'cell_annotation_and_QC.csv.gz',index_col=0)
        expected=set(original.index[original.Class.eq('Tumor')&original.qc_sensitivity_pass])
    else:
        assert cells.panel15_UCell.notna().all()
        assert not cells.predicted_doublet.any()
        expected=set()
        for source in (O/'epithelial_lineage_full_v1'/acc).glob('*/full_QC_doublet_annotations.csv.gz'):
            original=pd.read_csv(source,index_col=0)
            expected.update(original.index[original.tissue.eq('Primary_Tumor')&~original.predicted_doublet.astype(bool)])
    assert set(cells.index)==expected,'Scored-cell set must equal all prespecified eligible source cells'
    pat=pd.read_csv(folder/'patient_celltype_scores.csv').set_index(['patient','cell_type'])
    grouped=cells.groupby(['patient','cell_type']).panel14_UCell.agg(['mean','size'])
    np.testing.assert_allclose(pat.loc[grouped.index,'panel14_UCell'],grouped['mean'],atol=1e-12)
    np.testing.assert_array_equal(pat.loc[grouped.index,'cells'],grouped['size'])
    stats=pd.read_csv(folder/'all_paired_celltype_tests.csv');v=stats.p_value.notna()
    np.testing.assert_allclose(stats.loc[v,'FDR'],false_discovery_control(stats.loc[v,'p_value']),atol=1e-12)
    a=ad.read_h5ad(folder/'tsne_display.h5ad')
    assert not set(GENES)&set(a.var_names)
    assert a.obs.groupby('patient',observed=True).size().le(400).all()
    assert np.isfinite(a.obsm['X_tsne']).all()
    xy=pd.read_csv(folder/'tsne_coordinates_and_scores.csv.gz',index_col=0)
    np.testing.assert_allclose(xy.loc[a.obs_names,['tSNE1','tSNE2']],a.obsm['X_tsne'],rtol=1e-6,atol=1e-6)
    np.testing.assert_allclose(a.obs.panel14_UCell,cells.loc[a.obs_names,'panel14_UCell'],atol=1e-12)
    # Signature concordance at the patient/cell-type level, not a cell-level P value.
    from scipy.stats import spearmanr
    good=pat[pat.eligible]
    comparisons=[]
    for field in ['panel15_UCell','panel14_noTIMP1_UCell']:
        z=good[['panel14_UCell',field]].dropna()
        comparisons.append(dict(score=field,n_patient_celltype_groups=len(z),rho=float(spearmanr(z.iloc[:,0],z.iloc[:,1]).statistic) if len(z)>2 else None))
    results.append(dict(accession=acc,cells=len(cells),patients=cells.patient.nunique(),display_cells=a.n_obs,
      scored_libraries=len(statuses),sample_dense_rank_checks=sum(len(s['rank_checks']) for s in statuses),
      max_sample_dense_rank_error=max(v['max_error'] for s in statuses for v in s['rank_checks']),signature_concordance=comparisons))
r=json.loads((D/'implementation_validation/R_validation.json').read_text());assert r['completed'] and r['max_error']<1e-10
payload=dict(completed=True,exact_full_eligible_source_cell_coverage=True,all_patient_aggregates_checked=True,all_BH_recomputed=True,no_duplicate_cells=True,
  all15_genes_excluded_from_embedding=True,display_scores_match_full_cells=True,
  official_R_helper_sha256=hashlib.sha256((D/'implementation_validation/UCell_official_HelperFunctions.R').read_bytes()).hexdigest(),
  official_R_validation=r,cohorts=results,
  script_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path('work/rebuild/python/score_panel_single_cells.py'),Path('work/rebuild/python/analyze_panel_signature_tsne.py')]})
(D/'validation_checks.json').write_text(json.dumps(payload,indent=2))
print(json.dumps(payload,indent=2))
