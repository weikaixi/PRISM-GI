"""Independent alignment, raw-sum, NumPy inference and input-support audit."""
import json, hashlib
import numpy as np
import pandas as pd
import anndata as ad
from scipy.stats import spearmanr, false_discovery_control
from legacy_model_single_cell_scores import OUT, OLD, ACCS, Frozen, WEIGHTS, EXPECTED, model_validation, dump


def main():
    m=Frozen();model_validation(m)
    audits=[];features=[];comparisons=[];tech=[]
    for acc in ACCS:
        obs=pd.read_csv(OUT/acc/'all_cell_scores.csv.gz',index_col=0)
        source=pd.read_csv(OLD/acc/'all_tumor_cell_scores.csv.gz',index_col=0)
        assert obs.index.is_unique and obs.index.equals(source.index)
        assert obs.patient.equals(source.patient) and obs.cell_type.equals(source.cell_type)
        assert np.isfinite(obs.legacy_model_score).all()
        chunks=[ad.read_h5ad(p) for p in sorted((OUT/acc/'inputs').glob('*_counts158.h5ad'))]
        a=ad.concat(chunks,join='outer',merge='same')[obs.index,m.pool].copy()
        ranks=pd.DataFrame(a.X).rank(axis=1,pct=True,method='average').fillna(.5).to_numpy()
        center=json.loads((OUT/acc/'coverage_and_centers.json').read_text())
        np.testing.assert_allclose(ranks.mean(0),center['cell_center'],atol=1e-12)
        z=(ranks[:,m.ix]-.5*(np.array(center['cell_center'])[m.ix]-m.glob[m.ix])-m.mu)/m.sd
        w=m.a['state_dict']
        independent=(np.tanh(z@w['0.weight'].numpy().T+w['0.bias'].numpy())@w['3.weight'].numpy().T).ravel()
        np.testing.assert_allclose(independent,obs.legacy_model_score,atol=3e-6,rtol=3e-6)
        # Holding the declared transductive cohort center fixed must make
        # prediction independent of evaluation batching and row order.
        ix=np.arange(len(obs)-1,-1,-97)
        batch,_,_=m.predict(ranks[ix],np.array(center['cell_center']))
        np.testing.assert_allclose(batch,obs.legacy_model_score.iloc[ix],atol=2e-6,rtol=2e-6)
        patient=pd.read_csv(OUT/acc/'patient_celltype_scores.csv')
        pb=ad.read_h5ad(OUT/acc/'patient_celltype_raw_pseudobulk158.h5ad')
        raw=pd.DataFrame(a.X,index=a.obs_names,columns=m.pool)
        raw['patient']=obs.patient;raw['cell_type']=obs.cell_type
        sums=raw.groupby(['patient','cell_type'],observed=True)[m.pool].sum(min_count=1)
        keys=pd.MultiIndex.from_frame(patient[['patient','cell_type']])
        np.testing.assert_allclose(sums.loc[keys].to_numpy(),pb.X,atol=0,rtol=0,equal_nan=True)
        cellmeans=obs.groupby(['patient','cell_type'],observed=True).legacy_model_score.mean()
        np.testing.assert_allclose(cellmeans.loc[keys].to_numpy(),patient.mean_cell_legacy_score,atol=2e-7)
        pbr=pd.DataFrame(pb.X).rank(axis=1,pct=True,method='average').fillna(.5).to_numpy()
        eligible=patient.cells.ge(20).to_numpy()
        np.testing.assert_allclose(pbr[eligible].mean(0),center['pseudobulk_center'],atol=1e-12)
        ps,pz,_=m.predict(pbr,np.array(center['pseudobulk_center']))
        np.testing.assert_allclose(ps,patient.pseudobulk_legacy_score,atol=2e-7)
        coord=pd.read_csv(OUT/acc/'tsne_coordinates_and_model_scores.csv.gz',index_col=0)
        original=pd.read_csv(OLD/acc/'tsne_coordinates_and_scores.csv.gz',index_col=0)
        assert coord.index.equals(original.index)
        np.testing.assert_array_equal(coord[['tSNE1','tSNE2']],original[['tSNE1','tSNE2']])
        np.testing.assert_allclose(coord.legacy_model_score,obs.loc[coord.index,'legacy_model_score'],atol=0,rtol=0)
        t=pd.read_csv(OUT/acc/'paired_celltype_tests.csv');v=t.p_value.notna()
        np.testing.assert_allclose(t.loc[v,'FDR'],false_discovery_control(t.loc[v,'p_value']),atol=1e-12)
        for unit,q in [('single_cell',z),('eligible_pseudobulk',pz[eligible])]:
            for j,g in enumerate(m.genes):
                features.append(dict(accession=acc,unit=unit,gene=g,n=len(q),median_z=float(np.median(q[:,j])),
                    fraction_outside_training_range=float(((q[:,j]<m.low[j])|(q[:,j]>m.high[j])).mean()),
                    fraction_abs_z_gt3=float((abs(q[:,j])>3).mean()),train_min_z=float(m.low[j]),train_max_z=float(m.high[j])))
        good=patient.loc[eligible]
        for s in ['mean_cell_legacy_score','pseudobulk_legacy_score']:
            for u in ['panel14_UCell','panel15_UCell']:
                if good[u].notna().all():
                    comparisons.append(dict(accession=acc,comparison=s+' versus '+u,units=len(good),
                        rho=float(spearmanr(good[s],good[u]).statistic)))
        comparisons.append(dict(accession=acc,comparison='mean cell versus pseudobulk',units=len(good),
            rho=float(spearmanr(good.mean_cell_legacy_score,good.pseudobulk_legacy_score).statistic)))
        qc=pd.read_csv(OUT/acc/'within_patient_celltype_correlations.csv')
        for cov,part in qc.groupby('covariate'):
            tech.append(dict(accession=acc,covariate=cov,patient_celltypes=len(part),median_within_patient_celltype_rho=float(part.rho.median())))
        audits.append(dict(accession=acc,source_cell_set_exact=True,cells=len(obs),
            all_count_sums_exact=True,existing_tsne_coordinates_unchanged=True,
            network_numpy_max_error=float(abs(independent-obs.legacy_model_score.to_numpy()).max()),
            batching_order_verified=True,BH_verified=True))
        print('Validated',audits[-1],flush=True)
    pd.DataFrame(features).to_csv(OUT/'feature_training_support_audit.csv',index=False)
    pd.DataFrame(comparisons).to_csv(OUT/'patient_level_score_concordance.csv',index=False)
    pd.DataFrame(tech).to_csv(OUT/'technical_correlation_summary.csv',index=False)
    assert hashlib.sha256(WEIGHTS.read_bytes()).hexdigest()==EXPECTED
    dump(OUT/'validation_checks.json',dict(passed=True,cohorts=audits,weights_unchanged=True))


if __name__=='__main__':main()
