"""Validate the shared inference engine; does not rerun cell analyses."""
from pathlib import Path
import shutil
import subprocess

if __name__ == '__main__':
    node = shutil.which('node')
    if not node: raise RuntimeError('Node.js >=20 is required')
    root = Path(__file__).resolve().parents[3]
    subprocess.run([node, str(root/'test.mjs')], check=True)
