"""Exploratory UMAP, author cell labels, fixed sample-balanced display subset.

Neither UMAP nor this gene panel is a single-cell survival score.
"""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import scanpy as sc
import anndata as ad
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze_crc_single_cell import O, GENES, savefig

sys.stdout.reconfigure(encoding='utf-8')
SEED=20260916
sc.settings.n_jobs=4
ad.settings.allow_write_nullable_strings=True

def run(acc):
    out=O/acc; figs=out/'figures';rng=np.random.default_rng(SEED)
    a=ad.read_h5ad(out/'author_filtered_raw_counts.h5ad')
    qc=pd.read_csv(out/'cell_annotation_and_QC.csv.gz',index_col=0)
    a.obs=qc.loc[a.obs_names].copy()
    a=a[a.obs.qc_sensitivity_pass].copy()
    chosen=[]
    for _,ix in a.obs.groupby('Sample',observed=True,sort=True).indices.items():
        chosen.extend(rng.choice(ix,size=min(1000,len(ix)),replace=False))
    a=a[np.sort(chosen)].copy()
    print(acc,'embedding display subset',a.shape,flush=True)
    sc.pp.filter_genes(a,min_cells=5)
    sc.pp.normalize_total(a,target_sum=1e4)
    sc.pp.log1p(a)
    target=np.full((a.n_obs,len(GENES)),np.nan)
    available=[g for g in GENES if g in a.var_names]
    target[:,[GENES.index(g) for g in available]]=a[:,available].X.toarray()
    sc.pp.highly_variable_genes(a,n_top_genes=2500,flavor='seurat',batch_key='Sample')
    a.var['highly_variable']=a.var.highly_variable & ~a.var_names.isin(GENES) & ~a.var_names.str.startswith('MT-')
    hvg=a.var_names[a.var.highly_variable].tolist()
    print(acc,len(hvg),'HVGs excluding panel and mitochondrial genes',flush=True)
    e=a[:,a.var.highly_variable].copy()
    sc.pp.scale(e,max_value=10)
    sc.pp.pca(e,n_comps=30,random_state=SEED,svd_solver='arpack')
    sc.pp.neighbors(e,n_neighbors=15,n_pcs=30,random_state=SEED)
    sc.tl.umap(e,min_dist=.3,random_state=SEED)
    xy=e.obsm['X_umap']
    coords=e.obs.copy();coords['UMAP1']=xy[:,0];coords['UMAP2']=xy[:,1]
    coords.to_csv(out/'UMAP_display_subset_coordinates.csv.gz')
    e.write_h5ad(out/'UMAP_display_subset_HVG_processed.h5ad',compression='gzip')
    fig,axs=plt.subplots(1,3,figsize=(17,5.5))
    for ax,key in zip(axs,['Cell_type','Class','Patient']):
        labels=sorted(e.obs[key].unique())
        colors=plt.get_cmap('tab20' if len(labels)>10 else 'tab10')
        for k,label in enumerate(labels):
            sel=e.obs[key].to_numpy()==label
            ax.scatter(xy[sel,0],xy[sel,1],s=2,alpha=.65,c=[colors(k%colors.N)],label=label,rasterized=True)
        ax.set_title(key);ax.set_xlabel('UMAP 1');ax.set_ylabel('UMAP 2');ax.set_xticks([]);ax.set_yticks([])
        if len(labels)<=10:ax.legend(loc='upper center',bbox_to_anchor=(.5,-.04),ncol=2,fontsize=8,markerscale=4)
        else:ax.text(.02,.02,f'{len(labels)} patients (colors cycle)',transform=ax.transAxes,fontsize=8)
    fig.suptitle(f'{acc}: exploratory UMAP ({len(e):,} displayed cells; <=1,000 per tissue sample)')
    fig.text(.5,.01,'Author cell labels. No batch correction or malignant-cell inference. Display subset only; gene localization uses all author-filtered cells.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.1,1,.94]);savefig(fig,figs,'UMAP_author_labels_and_patient')
    fig,axs=plt.subplots(3,5,figsize=(17,10))
    for j,(ax,gene) in enumerate(zip(axs.flat,GENES)):
        if np.isnan(target[:,j]).all():
            ax.text(.5,.5,'Not available in source matrix',ha='center',va='center',transform=ax.transAxes,fontsize=9)
            ax.set_title(gene);ax.set_xticks([]);ax.set_yticks([])
            continue
        order=np.argsort(target[:,j]);v=target[:,j]
        vmax=max(float(np.quantile(v[v>0],.98)) if (v>0).any() else 0,.1)
        im=ax.scatter(xy[order,0],xy[order,1],c=v[order],s=2,cmap='viridis',vmin=0,vmax=vmax,rasterized=True)
        ax.set_title(gene);ax.set_xticks([]);ax.set_yticks([]);fig.colorbar(im,ax=ax,fraction=.035,pad=.01)
    fig.suptitle(f'{acc}: 15 genes, log1p(CP10K); gene-specific color scales')
    fig.tight_layout(rect=[0,0,1,.95]);savefig(fig,figs,'UMAP_15genes')
    (out/'UMAP_protocol.json').write_text(json.dumps(dict(seed=SEED,display_cells=e.n_obs,cap_per_tissue_sample=1000,
        normalization='log1p(CP10K)',HVGs=len(hvg),HVG_batch_key='Sample',excluded_HVG_panel=GENES,
        PCA=30,neighbors=15,min_dist=.3,batch_correction=False,malignancy_call=False),indent=2),encoding='utf-8')
    print(acc,'UMAP complete',flush=True)

if __name__=='__main__':
    for acc in ['GSE132465','GSE144735']:run(acc)
