"""Whole-transcriptome UCell, tumor-tissue cells; never a survival risk score."""
from pathlib import Path
import sys,json,gc,hashlib,importlib.metadata
import numpy as np
import pandas as pd
import anndata as ad
from scipy.stats import rankdata
from threadpoolctl import threadpool_limits
from analyze_crc_single_cell import O,GENES
from extend_three_cancer_localization import gc_samples,paad_samples

sys.stdout.reconfigure(encoding='utf-8')
ad.settings.allow_write_nullable_strings=True
D=O/'panel_signature_tsne_v1';D.mkdir(exist_ok=True)
SEED=20260918
P14=[g for g in GENES if g!='MUC2']
BROAD={'Epithelial cells':'Epithelial','Stromal cells':'Stromal','T cells':'T/NK','Myeloids':'Myeloid','B cells':'B/Plasma','Mast cells':'Mast'}

def exact_ucell(a,sig):
    """R UCell definition: average ties retained as floats; no order-based truncation.

    pyucell 0.7.3 floors average ranks and can discard tied genes in source order.
    Use exact sparse target ranks and independently verify against dense rankdata.
    """
    genes=a.var_names;available=[g for g in GENES if g in genes]
    target=a.X[:,genes.get_indexer(available)].toarray().astype(float)
    ranks=np.empty_like(target)
    for i in range(a.n_obs):
        values=a.X.data[a.X.indptr[i]:a.X.indptr[i+1]]
        values=np.sort(values[values>0].astype(float));n=len(values)
        l=np.searchsorted(values,target[i],side='left');r=np.searchsorted(values,target[i],side='right')
        ranks[i]=n-r+(r-l+1)/2
        ranks[i,target[i]==0]=(n+1+a.n_vars)/2
    ranks=np.minimum(ranks,1500)
    for name,gset in sig.items():
        n=len(gset);rs=ranks[:,[available.index(g) for g in gset]].sum(1)
        a.obs[name+'_UCell']=1-(rs-n*(n+1)/2)/(n*1500-n*(n+1)/2)

def process(acc,sample,raw,genes,obs):
    folder=D/acc;folder.mkdir(exist_ok=True);tag=sample.replace('.csv','')
    if (folder/f'{tag}_status.json').exists():return
    assert obs.index.is_unique and genes.is_unique and raw.shape==(len(obs),len(genes))
    a=ad.AnnData(raw.tocsr(),obs=obs.copy(),var=pd.DataFrame(index=genes))
    missing=[g for g in GENES if g not in genes];assert all(g in genes for g in P14)
    sig={'panel14':P14,'panel14_noTIMP1':[g for g in P14 if g!='TIMP1']}
    if not missing:sig['panel15']=GENES
    exact_ucell(a,sig)
    if missing:a.obs['panel15_UCell']=np.nan
    x=a.X[:,genes.get_indexer(P14)].toarray()
    a.obs['panel14_genes_detected']=(x>0).sum(1)
    a.obs['panel14_UMI']=x.sum(1)
    a.obs['TIMP1_UMI']=x[:,P14.index('TIMP1')]
    a.obs['accession']=acc
    # Independent dense-rank check, with exact average handling of tied zeros.
    checks=[]
    for i in np.linspace(0,len(a)-1,min(5,len(a)),dtype=int):
        ranks=rankdata(-a.X[i].toarray().ravel().astype(float),method='average')
        for name,gset in sig.items():
            n=len(gset);r=np.minimum(ranks[genes.get_indexer(gset)],1500)
            expected=1-(r.sum()-n*(n+1)/2)/(n*1500-n*(n+1)/2)
            got=float(a.obs.iloc[i][name+'_UCell']);assert abs(got-expected)<1e-6
            checks.append(dict(cell=str(a.obs_names[i]),signature=name,max_error=abs(got-expected)))
    a.obs.to_csv(folder/f'{tag}_cell_scores.csv.gz')
    rng=np.random.default_rng(SEED)
    ids=[]
    for p,ix in a.obs.groupby('patient',observed=True).indices.items():
        ids.extend(rng.choice(ix,min(400,len(ix)),replace=False))
    a[np.sort(ids)].copy().write_h5ad(folder/f'{tag}_display_raw.h5ad',compression='gzip')
    status=dict(completed=True,accession=acc,sample=sample,cells=a.n_obs,source_genes=a.n_vars,
      missing_panel_genes=missing,display_cells=len(ids),rank_checks=checks,
      signatures={k:len(v) for k,v in sig.items()})
    (folder/f'{tag}_status.json').write_text(json.dumps(status,indent=2))
    print(acc,sample,a.n_obs,'cells scored',flush=True);del a;gc.collect()

def main(acc):
    if acc=='GSE132465':
        a=ad.read_h5ad(O/acc/'author_filtered_raw_counts.h5ad')
        obs=pd.read_csv(O/acc/'cell_annotation_and_QC.csv.gz',index_col=0).reindex(a.obs_names)
        mask=obs.Class.eq('Tumor')&obs.qc_sensitivity_pass
        obs=obs.loc[mask].copy();obs['patient']=obs.Patient;obs['sample']=obs.Sample
        obs['cell_type']=obs.Cell_type.map(BROAD);obs['tissue']='Primary_Tumor'
        obs['annotation_source']='author';obs['doublet_screen']='not independently rerun for CRC'
        process(acc,'tumor_all',a.X[np.flatnonzero(mask)],a.var_names,obs)
    else:
        generator=gc_samples if acc=='GSE183904' else paad_samples
        for accession,sample,patient,tissue,raw,genes,cells in generator():
            if tissue!='Primary_Tumor':continue
            folder=O/'epithelial_lineage_full_v1'/acc/sample.replace('.csv','')
            obs=pd.read_csv(folder/'full_QC_doublet_annotations.csv.gz',index_col=0)
            assert obs.doublet_status.eq('completed').all()
            obs=obs.loc[~obs.predicted_doublet.astype(bool)].copy()
            obs['cell_type']=obs.broad_label;obs['annotation_source']='provisional independent marker rules'
            idx=pd.Index([sample+'|'+str(z) for z in cells]).get_indexer(obs.index);assert (idx>=0).all()
            process(acc,sample,raw[idx],genes,obs)
            del raw;gc.collect()
    (D/acc/'scoring_complete.json').write_text(json.dumps(dict(completed=True,cohort=acc)))

if __name__=='__main__':
    protocol=dict(seed=SEED,method='R UCell formula reproduced with exact sparse target ranks; max_rank=1500, float average ties, whole source transcriptome; independently checked against dense ranks',
      implementation_audit='pyucell 0.7.3 rejected before outputs: average ranks are cast to int32 and tied genes can be truncated in matrix order. No scoring outputs from that implementation used.',
      score_meaning='unsigned expression signature enrichment; NOT formal three-domain projection, NOT survival risk',
      primary='common 14 genes excluding source-missing MUC2; same gene set across all three cohorts',
      full15='GC and PAAD only; CRC has missing source MUC2 and its 15-gene score is NA, not zero-imputed',
      sensitivity='14-gene signature without TIMP1, explicitly 13 genes; descriptive dominance check, not model reselection',
      cells='tumor tissue only; CRC author cells with pre-existing sensitivity QC; GC/PAAD full-QC predicted singlets; Uncertain labels retained',
      aggregation='patient x cell type, >=20 cells; all scored cells used, patients equally weighted',
      display='up to 400 cells per library/patient pool, subsequently at most 400 per patient; display only, not statistical subset',
      embedding='separate cohort tSNE; exclude ALL 15 genes and MT/RPL/RPS from HVG/PCA; same coordinates for all overlays; no batch correction',
      limits=['source annotation/QC differ across cohorts','dropout and technical-depth dependence','no high/low-risk labeling or optimized cutpoint','no signed weights, formal survival model or clinical OS inference','no CRC MUC2 imputation','patient averages do not estimate cell contributions to bulk risk'],
      genes=GENES,software={p:importlib.metadata.version(p) for p in ['pyucell','scanpy','anndata','numpy','scikit-learn']},
      source='https://github.com/carmonalab/UCell/blob/master/R/HelperFunctions.R',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (D/'protocol.json').write_text(json.dumps(protocol,indent=2))
    with threadpool_limits(limits=2):main(sys.argv[1])
