"""Full-QC epithelial lineage staging with per-library Scrublet audit."""
import sys,gc,json,hashlib,importlib.metadata
from pathlib import Path
import numpy as np
import pandas as pd
import scanpy as sc
import anndata as ad
from threadpoolctl import threadpool_limits
from extend_three_cancer_localization import gc_samples,paad_samples
from analyze_crc_single_cell import O,GENES

sys.stdout.reconfigure(encoding='utf-8')
ad.settings.allow_write_nullable_strings=True
sc.settings.n_jobs=2
SEED=20260917
D=O/'epithelial_lineage_full_v1';D.mkdir(exist_ok=True)
S=O/'three_cancer_localization_v1'
LINEAGES={
 'GSE155698':{
  'Acinar_like':['PRSS1','PRSS2','CPA1','CTRB2','CELA3A','PNLIP'],
  'Ductal_like':['KRT7','KRT19','CFTR','SOX9','EPCAM','KRT18'],
  'Endocrine_like':['CHGA','CHGB','SCG5','SYP','ISL1','PCSK1']},
 'GSE183904':{
  'Pit_surface_like':['TFF1','MUC5AC','GKN1','GKN2'],
  'Chief_like':['PGC','PGA3','PGA4','LIPF'],
  'Mucous_neck_like':['MUC6','TFF2','AQP5','SPINK4'],
  'Enterocyte_like':['ALPI','FABP1','FABP2','APOA4','SI'],
  'Endocrine_like':['CHGA','CHGB','SCG5','SYP'],
  'Parietal_like':['ATP4A','ATP4B','GIF','SLC26A7']}}
# Markers used for lineage definition never include a prognostic-panel gene.
assert not set(GENES)&set(g for v in LINEAGES.values() for z in v.values() for g in z)
NON_EPI={
 'immune':['PTPRC','CD3D','CD3E','TRAC','LST1','TYROBP','MS4A1','CD79A'],
 'stromal':['COL1A1','COL1A2','DCN','LUM','PECAM1','VWF','RGS5','CSPG4']}

def lineage_labels(raw,genes,total,acc):
    values=[];detected=[]
    for markers in LINEAGES[acc].values():
        pos=[genes.get_loc(g) for g in markers if g in genes]
        v=raw[:,pos].toarray()
        values.append(np.log1p(v/np.maximum(total[:,None],1)*10000).sum(1)/len(markers))
        detected.append((v>0).sum(1))
    score=np.array(values).T;counts=np.array(detected).T
    eligible=(counts>=2)&(score>=.5)
    effective=np.where(eligible,score,-1);ix=effective.argmax(1)
    best=effective[np.arange(len(ix)),ix];second=np.partition(effective,-2,axis=1)[:,-2]
    labels=np.array(list(LINEAGES[acc]),dtype=object)[ix]
    labels[best<0]='Epithelial_unresolved'
    labels[(best>=0)&(second>=0)&((best-second)<.25)]='Mixed_lineage'
    conflict=np.zeros(len(ix),bool)
    for markers in NON_EPI.values():
        pos=[genes.get_loc(g) for g in markers if g in genes];v=raw[:,pos].toarray()
        count=(v>0).sum(1);mean=np.log1p(v/np.maximum(total[:,None],1)*10000).sum(1)/len(markers)
        conflict|=(count>=3)&(mean>=.75)
    return labels,best,np.maximum(best-second,0),conflict,score

def process(data):
    acc,sample,patient,tissue,raw,genes,cells=data
    out=D/acc/sample.replace('.csv','');out.mkdir(parents=True,exist_ok=True)
    if (out/'status.json').exists():return
    ann=pd.read_csv(S/f'{acc}_{sample.replace(".csv","")}_QC_annotations.csv.gz',index_col=0)
    indices=[sample+'|'+str(c) for c in cells];ann=ann.loc[indices]
    assert len(ann)==raw.shape[0] and ann.patient.astype(str).eq(patient).all()
    idx=np.flatnonzero(ann.QC_pass.to_numpy());qc=ann.iloc[idx].copy()
    a=ad.AnnData(raw[idx].astype(np.float32),obs=qc.copy(),var=pd.DataFrame(index=genes))
    dbstatus='completed';err='';threshold=None
    try:
        sc.pp.scrublet(a,expected_doublet_rate=.05,sim_doublet_ratio=2,n_prin_comps=30,
                       random_state=SEED,use_approx_neighbors=False,verbose=False)
        assert 'predicted_doublet' in a.obs and a.obs.predicted_doublet.notna().all()
        qc['doublet_score']=a.obs.doublet_score.to_numpy()
        qc['predicted_doublet']=a.obs.predicted_doublet.to_numpy()
        threshold=float(a.uns['scrublet']['threshold'])
        np.savez_compressed(out/'scrublet_score_distributions.npz',observed=qc.doublet_score.to_numpy(),simulated=a.uns['scrublet']['doublet_scores_sim'])
    except Exception as e:
        dbstatus='failed';err=repr(e);qc['doublet_score']=np.nan;qc['predicted_doublet']=pd.NA
    qc['doublet_status']=dbstatus
    qc.to_csv(out/'full_QC_doublet_annotations.csv.gz')
    mask=qc.broad_label.to_numpy()=='Epithelial';x=raw[idx[mask]].tocsr();obs=qc.iloc[np.flatnonzero(mask)].copy()
    labels,best,margin,conflict,score=lineage_labels(x,genes,obs.total_UMI.to_numpy(),acc)
    obs['lineage']=labels;obs['lineage_score']=best;obs['lineage_margin']=margin;obs['non_epithelial_marker_conflict']=conflict
    # Only cells with successful doublet checks, no predicted doublet and no strong
    # cross-lineage conflict enter the strict analysis; originals stay intact.
    obs['strict_keep']=(dbstatus=='completed') & (~obs.predicted_doublet.fillna(True).astype(bool)) & (~conflict)
    obs['predicted_doublet']=obs.predicted_doublet.fillna(False).astype(bool)
    for j,name in enumerate(LINEAGES[acc]):obs['score_'+name]=score[:,j]
    ep=ad.AnnData(x,obs=obs,var=pd.DataFrame(index=genes))
    ep.write_h5ad(out/'epithelial_counts_with_lineages.h5ad',compression='gzip')
    obs.to_csv(out/'epithelial_cell_lineages.csv.gz')
    status=dict(accession=acc,sample=sample,patient=patient,tissue=tissue,QC_cells=len(qc),
      scrublet_status=dbstatus,scrublet_error=err,scrublet_threshold=threshold,
      predicted_doublets=int(qc.predicted_doublet.fillna(False).sum()) if dbstatus=='completed' else None,
      epithelial_candidates=len(obs),epithelial_strict=int(obs.strict_keep.sum()),
      epithelial_predicted_doublets=int(obs.predicted_doublet.sum()) if dbstatus=='completed' else None,
      non_epithelial_conflicts=int(conflict.sum()),lineages=obs.lineage.value_counts().to_dict())
    (out/'status.json').write_text(json.dumps(status,indent=2))
    print(json.dumps(status),flush=True)
    del a,ep,x;gc.collect()

def main():
    protocol=dict(seed=SEED,lineage_markers=LINEAGES,excluded_panel=GENES,
       candidate_cells='ALL QC cells with prior broad epithelial marker label, including acinar/endocrine; no UMAP subsampling',
       classifier='>=2 detected markers and mean log1p(CP10K)>=0.5; winner gap>=0.25; otherwise Mixed_lineage or Epithelial_unresolved',
       cross_lineage_conflict_markers=NON_EPI,conflict='>=3 immune or stromal markers and group mean log1p(CP10K)>=0.75',
       doublets='Scrublet separately on ALL QC cells of each library, not only epithelial; auto threshold, expected rate 0.05 assumed, seed fixed',
       strict='Successful Scrublet, predicted singlet and no strong cross-lineage marker conflict; original cells also retained',
       limitations=['No empty droplets to estimate ambient contamination','Heuristic lineage labels, not author labels or malignant calls',
          'Expected doublet rate is an unvalidated assumption; retain all candidates for sensitivity','Strict excludes failed doublet checks; unknown is not singlet'],
       sources=['https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE155698','https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE183904',
         'https://scanpy.readthedocs.io/en/latest/api/generated/scanpy.pp.scrublet.html'])
    (D/'protocol.json').write_text(json.dumps(protocol,indent=2))
    for generator in [paad_samples,gc_samples]:
        for data in generator():process(data)
    statuses=[json.loads(p.read_text()) for p in D.glob('*/*/status.json')]
    pd.json_normalize(statuses).to_csv(D/'sample_processing_summary.csv',index=False)
    (D/'status.json').write_text(json.dumps(dict(completed=True,libraries=len(statuses),
       summary=pd.DataFrame(statuses).groupby('accession')[['QC_cells','epithelial_candidates','epithelial_strict']].sum().to_dict('index'),
       doublet_failed=sum(r['scrublet_status']!='completed' for r in statuses)),indent=2))
    print('FULL EPITHELIAL STAGING COMPLETE',flush=True)

if __name__=='__main__':
    with threadpool_limits(limits=2):main()
