import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {prepareCohort,predictCohort} from './prediction/engine.mjs';
import {clinicalRows,addSurvival,combinedCSV} from './prediction/clinical-cohort.mjs';
const [input,cancer,output,...flags]=process.argv.slice(2);
if(!input||!output||!['colorectal','gastric','pancreatic'].includes(cancer)||flags.some(f=>f!=='--nomogram')){
  console.error('Usage: node predict.mjs INPUT.csv colorectal|gastric|pancreatic OUTPUT.csv [--nomogram]');process.exit(2);
}
if(fs.existsSync(output)){console.error('Output already exists; choose a new filename.');process.exit(2);}
const readJSON=name=>JSON.parse(fs.readFileSync(fileURLToPath(new URL('./prediction/'+name,import.meta.url)),'utf8'));
try {
  const text=fs.readFileSync(input,'utf8');const model=readJSON('model.json');
  const result=predictCohort(prepareCohort(text,model),model);
  if(flags.includes('--nomogram')){
    addSurvival(result,clinicalRows(text),cancer,readJSON('nomogram.json'));
    for(const w of new Set(result.results.flatMap(r=>r.nomogram.warnings)))console.warn(w);
  }
  fs.writeFileSync(output,combinedCSV(result,cancer),{flag:'wx'});
  console.log(`Saved ${result.n} predictions to ${output}`);
}catch(e){console.error(e.message);process.exitCode=1;}
