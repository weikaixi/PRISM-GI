library(CrossDomainAdjust)

local({
  set.seed(319)
  labels <- rep(c("A", "B", "C"), c(9, 13, 17))
  x <- matrix(rnorm(length(labels) * 6), ncol = 6)
  x[, 1] <- x[, 1] + as.integer(factor(labels)) * 2
  colnames(x) <- paste0("g", 1:6)
  for (anchor in c("domain_mean", "sample_mean")) {
    fit <- fit_domain_projector(x, labels, anchor)
    p <- fit$projection_matrix
    stopifnot(fit$rank <= 2L,
              isTRUE(all.equal(p, t(p))),
              isTRUE(all.equal(p %*% p, p)),
              identical(project_features(fit, x, 0), x))
    full <- project_features(fit, x, 1)
    half <- project_features(fit, x, 0.5)
    stopifnot(isTRUE(all.equal(half, (x + full) / 2)),
              isTRUE(all.equal(project_features(fit, full, 1), full)))
    for (label in unique(labels)) {
      stopifnot(max(abs(colMeans(full[labels == label, , drop = FALSE]) -
                          fit$projection_anchor)) < 1e-10)
    }
    stopifnot(isTRUE(all.equal(project_features(fit, x[, 6:1], 0.5), half)))
    perm <- sample(nrow(x))
    reordered <- fit_domain_projector(x[perm, ], labels[perm], anchor)
    stopifnot(isTRUE(all.equal(reordered$projection_matrix, p)))
  }
  z <- matrix(c(0, 0, 1, 0), ncol = 2, byrow = TRUE,
              dimnames = list(NULL, c("a", "b")))
  stopifnot(fit_domain_projector(z, c("A", "B"))$rank == 1L,
            fit_domain_projector(z, c("A", "B"), c(a = 0, b = 1))$rank == 2L)
})
