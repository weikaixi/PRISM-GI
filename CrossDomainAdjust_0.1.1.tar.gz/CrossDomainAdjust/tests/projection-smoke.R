library(CrossDomainAdjust)

x <- matrix(c(
  0, 0,
  1, 0,
  4, 4,
  5, 4
), ncol = 2, byrow = TRUE)
colnames(x) <- c("a", "b")
projector <- fit_domain_projector(x, c("A", "A", "B", "B"))
corrected <- project_features(projector, x, lambda = 0)
stopifnot(isTRUE(all.equal(corrected, x)))

projector_sample_mean <- fit_domain_projector(x, c("A", "A", "B", "B"), anchor = "sample_mean")
stopifnot(identical(projector_sample_mean$anchor_type, "sample_mean"))

custom_anchor <- setNames(c(2, 2), colnames(x))
projector_custom <- fit_domain_projector(x, c("A", "A", "B", "B"), anchor = custom_anchor)
stopifnot(identical(projector_custom$anchor_type, "custom"))
stopifnot(isTRUE(all.equal(projector_custom$projection_anchor, custom_anchor)))

set.seed(7)
for (k in 2:4) {
  domains <- paste0("D", seq_len(k))
  train <- do.call(
    rbind,
    lapply(seq_along(domains), function(i) matrix(rnorm(30, mean = i), nrow = 6))
  )
  colnames(train) <- paste0("g", seq_len(ncol(train)))
  projector <- fit_domain_projector(train, rep(domains, each = 6))
  sample <- setNames(rnorm(ncol(train)), colnames(train))
  corrected <- project_new_sample(projector, sample, domain = domains[1], lambda = 0.5)
  stopifnot(length(corrected) == ncol(train))
  stopifnot(identical(names(corrected), colnames(train)))
}
