library(CrossDomainAdjust)

local({
  pdf_file <- tempfile(fileext = ".pdf")
  pdf(pdf_file)
  caller_device <- dev.cur()
  on.exit({
    dev.off(caller_device)
    unlink(pdf_file)
  })
  par(mfrow = c(1, 2), mar = c(3, 4, 2, 1))
  before_par <- par(no.readonly = TRUE)
  before_wd <- getwd()
  before_options <- options()
  scripts <- list.files(system.file("examples", package = "CrossDomainAdjust"),
                        pattern = "^[0-9].*\\.R$", full.names = TRUE)
  stopifnot(length(scripts) == 3L)
  for (script in scripts) {
    env <- new.env(parent = globalenv())
    devices_before <- dev.list()
    capture.output(suppressMessages(sys.source(script, envir = env)))
    stopifnot(identical(dev.list(), devices_before),
              identical(dev.cur(), caller_device),
              identical(par(no.readonly = TRUE), before_par),
              identical(getwd(), before_wd),
              identical(options(), before_options))
    # Force failure after opening the example device and changing parameters.
    env <- new.env(parent = globalenv())
    env$plot <- function(...) stop("intentional plotting failure")
    failed <- try(suppressMessages(sys.source(script, envir = env)), silent = TRUE)
    stopifnot(inherits(failed, "try-error"),
              identical(dev.list(), devices_before),
              identical(dev.cur(), caller_device),
              identical(par(no.readonly = TRUE), before_par),
              identical(getwd(), before_wd),
              identical(options(), before_options))
  }
})
