# CrossDomainAdjust 0.1.1

* Restore graphical parameters in the PCA example, including on errors.
* Close only the graphics device opened by each plotting example on exit.
* Clarify the centroid/SVD algorithm and the custom-anchor rank bound.
* Add projection-invariant and example-state regression tests.
* No changes to the numerical projection algorithm or exported API.

# CrossDomainAdjust 0.1.0

* Initial CRAN-preparation release.
* Added lambda-controlled projection correction for cross-domain feature adjustment.
* Added support for two, three, four, or more domains.
* Added user-selectable projection anchors: `"domain_mean"`, `"sample_mean"`, or a custom named vector.
* Added examples for lambda-dependent PCA overlap, two-domain new-sample correction, and three-domain new-sample correction.
