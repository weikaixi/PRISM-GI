library(CrossDomainAdjust)

# Example 2:
# Two-domain use case. The user supplies:
#   1. first cohort feature matrix
#   2. second cohort feature matrix
#   3. lambda
#   4. one new sample and its source cohort
# The example outputs the corrected feature vector and a PCA plot showing
# cohort centers plus the new sample's movement before and after correction.

set.seed(20260811)

out_dir <- file.path(tempdir(), "CrossDomainAdjust_examples")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

n_features <- 30
feature_names <- paste0("gene_", seq_len(n_features))

# User input 1: first cohort feature matrix.
cohort1 <- matrix(rnorm(70 * n_features, mean = 0, sd = 1), nrow = 70)

# User input 2: second cohort feature matrix with a batch effect.
batch_shift <- c(rep(2.0, 8), rep(-1.4, 7), rep(0, n_features - 15))
cohort2 <- matrix(rnorm(70 * n_features, mean = 0, sd = 1), nrow = 70)
cohort2 <- sweep(cohort2, 2, batch_shift, FUN = "+")

colnames(cohort1) <- feature_names
colnames(cohort2) <- feature_names
rownames(cohort1) <- paste0("A_", seq_len(nrow(cohort1)))
rownames(cohort2) <- paste0("B_", seq_len(nrow(cohort2)))

# User input 3: correction strength.
lambda <- 0.8

training_x <- rbind(cohort1, cohort2)
training_domain <- c(rep("Cohort_A", nrow(cohort1)), rep("Cohort_B", nrow(cohort2)))
projector <- fit_domain_projector(training_x, training_domain, anchor = "domain_mean")

# User input 4: one new sample and its source cohort.
new_sample <- setNames(rnorm(n_features), feature_names)
new_sample <- new_sample + batch_shift
new_sample_domain <- "Cohort_B"

corrected_sample <- project_new_sample(
  projector,
  sample = new_sample,
  domain = new_sample_domain,
  lambda = lambda
)

write.csv(
  data.frame(
    feature = names(corrected_sample),
    original_value = as.numeric(new_sample),
    corrected_value = as.numeric(corrected_sample)
  ),
  file.path(out_dir, "example2_new_sample_corrected_features.csv"),
  row.names = FALSE
)

# PCA visualization. Fit PCA on training plus both versions of the new sample
# so the displayed movement is directly visible in the plotted coordinate
# system.
display_x <- rbind(
  training_x,
  new_original = new_sample,
  new_corrected = corrected_sample
)
pca_fit <- prcomp(display_x, center = TRUE, scale. = TRUE)
scores <- pca_fit$x[, 1:2, drop = FALSE]
training_scores <- scores[rownames(training_x), , drop = FALSE]
new_original_score <- scores["new_original", , drop = FALSE]
new_corrected_score <- scores["new_corrected", , drop = FALSE]

center_scores <- aggregate(training_scores, by = list(domain = training_domain), FUN = mean)
center_a <- as.numeric(center_scores[center_scores$domain == "Cohort_A", c("PC1", "PC2")])
center_b <- as.numeric(center_scores[center_scores$domain == "Cohort_B", c("PC1", "PC2")])
all_display_scores <- rbind(
  training_scores,
  center_a,
  center_b,
  new_original_score,
  new_corrected_score
)
x_limits <- range(all_display_scores[, 1])
y_limits <- range(all_display_scores[, 2])
x_limits <- x_limits + c(-1, 1) * 0.08 * diff(x_limits)
y_limits <- y_limits + c(-1, 1) * 0.10 * diff(y_limits)

local({
png(file.path(out_dir, "example2_new_sample_pca.png"), width = 1400, height = 950, res = 150)
example_device <- dev.cur()
on.exit(dev.off(example_device), add = TRUE)
colors <- ifelse(training_domain == "Cohort_A", "#2f6fbb", "#c94f44")
plot(
  training_scores[, 1],
  training_scores[, 2],
  col = adjustcolor(colors, alpha.f = 0.50),
  pch = 16,
  xlim = x_limits,
  ylim = y_limits,
  xlab = "PC1",
  ylab = "PC2",
  main = paste0("Two-domain new sample correction, lambda = ", lambda),
  cex = 0.75
)
grid(col = "gray88")
segments(center_a[1], center_a[2], center_b[1], center_b[2], col = "gray35", lwd = 2, lty = 2)
points(center_a[1], center_a[2], pch = 23, bg = "#2f6fbb", col = "black", cex = 2.2, lwd = 1.2)
points(center_b[1], center_b[2], pch = 23, bg = "#c94f44", col = "black", cex = 2.2, lwd = 1.2)
text(center_a[1], center_a[2], labels = " center A", pos = 4, cex = 0.85)
text(center_b[1], center_b[2], labels = " center B", pos = 4, cex = 0.85)
points(new_original_score[, 1], new_original_score[, 2], pch = 4, cex = 2.2, lwd = 2.5, col = "black")
points(new_corrected_score[, 1], new_corrected_score[, 2], pch = 8, cex = 2.2, lwd = 2.5, col = "#1b9e77")
arrows(
  new_original_score[, 1],
  new_original_score[, 2],
  new_corrected_score[, 1],
  new_corrected_score[, 2],
  length = 0.10,
  lwd = 2,
  col = "#1b9e77"
)
legend(
  "topright",
  legend = c(
    "Cohort_A training",
    "Cohort_B training",
    "cohort centers",
    "center connection",
    "new sample original",
    "new sample corrected"
  ),
  col = c("#2f6fbb", "#c94f44", "black", "gray35", "black", "#1b9e77"),
  pch = c(16, 16, 23, NA, 4, 8),
  lty = c(NA, NA, NA, 2, NA, NA),
  pt.bg = c(NA, NA, "white", NA, NA, NA),
  cex = 0.85,
  bty = "n"
)
})

print(head(corrected_sample, 10))
message("Example 2 outputs written to: ", out_dir)
