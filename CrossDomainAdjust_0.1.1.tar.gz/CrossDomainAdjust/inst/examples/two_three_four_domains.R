library(CrossDomainAdjust)

make_example <- function(k_domains) {
  set.seed(100 + k_domains)
  domains <- paste0("D", seq_len(k_domains))
  x <- do.call(
    rbind,
    lapply(seq_along(domains), function(i) {
      matrix(rnorm(8 * 5, mean = i - 1), nrow = 8, ncol = 5)
    })
  )
  colnames(x) <- paste0("feature", seq_len(ncol(x)))
  domain <- rep(domains, each = 8)

  projector <- fit_domain_projector(x, domain)
  sample <- setNames(rnorm(5), colnames(x))
  corrected <- project_new_sample(projector, sample, domain = domains[1], lambda = 0.5)

  list(projector = projector, corrected = corrected)
}

two_domains <- make_example(2)
three_domains <- make_example(3)
four_domains <- make_example(4)
