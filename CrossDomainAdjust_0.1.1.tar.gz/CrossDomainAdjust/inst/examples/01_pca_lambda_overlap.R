library(CrossDomainAdjust)

# Example 1:
# Simulate two cohorts with a clear batch effect, then show how increasing
# lambda makes the PCA distributions overlap more.

set.seed(20260810)

out_dir <- file.path(tempdir(), "CrossDomainAdjust_examples")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

n_per_batch <- 120
n_features <- 60
lambda_values <- c(0, 0.25, 0.5, 0.75, 1)

make_simulation <- function() {
  n <- n_per_batch * 2
  batch <- rep(c("Cohort_A", "Cohort_B"), each = n_per_batch)
  subtype <- rep(rep(c("Subtype_1", "Subtype_2"), each = n_per_batch / 2), 2)

  latent_bio <- ifelse(subtype == "Subtype_2", 1, -1) + rnorm(n, sd = 0.35)
  bio_loading <- c(rep(1.25, 10), rep(-0.9, 8), rep(0.45, 7), rep(0, n_features - 25))
  bio_signal <- outer(latent_bio, bio_loading)

  noise <- matrix(rnorm(n * n_features, sd = 0.8), nrow = n, ncol = n_features)

  batch_shift <- rep(0, n_features)
  batch_shift[1:18] <- seq(2.4, 1.0, length.out = 18)
  batch_shift[19:30] <- seq(-1.7, -0.6, length.out = 12)
  batch_signal <- outer(batch == "Cohort_B", batch_shift)

  x <- bio_signal + batch_signal + noise
  colnames(x) <- paste0("feature_", seq_len(n_features))
  rownames(x) <- paste0("sample_", seq_len(n))
  list(x = x, batch = batch, subtype = subtype)
}

run_pca <- function(x) {
  prcomp(x, center = TRUE, scale. = TRUE)$x[, 1:2, drop = FALSE]
}

centroid_distance <- function(scores, batch) {
  centers <- aggregate(scores, by = list(batch = batch), FUN = mean)
  a <- as.numeric(centers[centers$batch == "Cohort_A", c("PC1", "PC2")])
  b <- as.numeric(centers[centers$batch == "Cohort_B", c("PC1", "PC2")])
  sqrt(sum((a - b)^2))
}

mixing_score <- function(scores, batch, k = 10) {
  distances <- as.matrix(dist(scores))
  diag(distances) <- Inf
  neighbor_idx <- t(apply(distances, 1, function(x) order(x)[seq_len(k)]))
  neighbor_batch <- matrix(batch[neighbor_idx], nrow = nrow(neighbor_idx), ncol = ncol(neighbor_idx))
  same_batch_fraction <- rowMeans(neighbor_batch == batch)
  1 - mean(same_batch_fraction)
}

plot_panel <- function(scores, batch, subtype, lambda, centroid_dist, mix_score) {
  colors <- ifelse(batch == "Cohort_A", "#2f6fbb", "#c94f44")
  shapes <- ifelse(subtype == "Subtype_1", 16, 17)
  plot(
    scores[, 1],
    scores[, 2],
    col = adjustcolor(colors, alpha.f = 0.78),
    pch = shapes,
    xlab = "PC1",
    ylab = "PC2",
    main = paste0(
      "lambda = ", lambda,
      "\ncentroid distance = ", sprintf("%.2f", centroid_dist),
      ", mixing = ", sprintf("%.2f", mix_score)
    ),
    cex = 0.85
  )
  grid(col = "gray88")
}

sim <- make_simulation()
projector <- fit_domain_projector(sim$x, sim$batch, anchor = "domain_mean")

plot_rows <- list()
metric_rows <- list()
for (lambda in lambda_values) {
  adjusted <- project_features(projector, sim$x, lambda = lambda)
  scores <- run_pca(adjusted)
  colnames(scores) <- c("PC1", "PC2")
  cd <- centroid_distance(scores, sim$batch)
  ms <- mixing_score(scores, sim$batch)
  plot_rows[[as.character(lambda)]] <- list(scores = scores, centroid_distance = cd, mixing_score = ms)
  metric_rows[[as.character(lambda)]] <- data.frame(
    lambda = lambda,
    pca_batch_centroid_distance = cd,
    pca_neighbor_mixing_score = ms,
    projection_rank = projector$rank
  )
}

metrics <- do.call(rbind, metric_rows)
write.csv(metrics, file.path(out_dir, "example1_pca_lambda_metrics.csv"), row.names = FALSE)

local({
png(file.path(out_dir, "example1_pca_lambda_overlap.png"), width = 1800, height = 1050, res = 150)
example_device <- dev.cur()
on.exit(dev.off(example_device), add = TRUE)
oldpar <- par(no.readonly = TRUE)
on.exit(par(oldpar), add = TRUE, after = FALSE)
par(mfrow = c(2, 3), mar = c(4, 4, 4, 1), oma = c(0, 0, 3, 0))
for (lambda in lambda_values) {
  item <- plot_rows[[as.character(lambda)]]
  plot_panel(item$scores, sim$batch, sim$subtype, lambda, item$centroid_distance, item$mixing_score)
}
plot.new()
legend(
  "center",
  legend = c("Cohort_A", "Cohort_B", "Subtype_1", "Subtype_2"),
  col = c("#2f6fbb", "#c94f44", "black", "black"),
  pch = c(16, 16, 16, 17),
  bty = "n",
  cex = 1.1
)
mtext("Projection correction: two cohorts with batch effect", outer = TRUE, cex = 1.25, font = 2)
})

print(metrics)
message("Example 1 outputs written to: ", out_dir)
