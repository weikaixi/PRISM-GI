library(CrossDomainAdjust)

# Example 3:
# Three-domain use case. Three domain centers form a triangle in feature space.
# The projector removes up to two independent domain directions. The PCA plot
# shows the three centers, their triangle, and one new sample before and after
# correction.

set.seed(20260812)

out_dir <- file.path(tempdir(), "CrossDomainAdjust_examples")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

n_features <- 36
n_per_domain <- 65
feature_names <- paste0("gene_", seq_len(n_features))

shift_a <- c(rep(0, n_features))
shift_b <- c(rep(2.2, 9), rep(-1.0, 9), rep(0, n_features - 18))
shift_c <- c(rep(-1.5, 6), rep(1.8, 8), rep(-1.2, 8), rep(0, n_features - 22))
shifts <- list(COADREAD = shift_a, STAD = shift_b, PAAD = shift_c)

make_domain <- function(domain_name) {
  x <- matrix(rnorm(n_per_domain * n_features, sd = 1), nrow = n_per_domain)
  x <- sweep(x, 2, shifts[[domain_name]], FUN = "+")
  colnames(x) <- feature_names
  rownames(x) <- paste0(domain_name, "_", seq_len(nrow(x)))
  x
}

coadread <- make_domain("COADREAD")
stad <- make_domain("STAD")
paad <- make_domain("PAAD")

lambda <- 0.85
training_x <- rbind(coadread, stad, paad)
training_domain <- c(
  rep("COADREAD", nrow(coadread)),
  rep("STAD", nrow(stad)),
  rep("PAAD", nrow(paad))
)
projector <- fit_domain_projector(training_x, training_domain, anchor = "domain_mean")

new_sample_domain <- "PAAD"
new_sample <- setNames(rnorm(n_features), feature_names)
new_sample <- new_sample + shifts[[new_sample_domain]]
corrected_sample <- project_new_sample(projector, new_sample, domain = new_sample_domain, lambda = lambda)

write.csv(
  data.frame(
    feature = names(corrected_sample),
    original_value = as.numeric(new_sample),
    corrected_value = as.numeric(corrected_sample)
  ),
  file.path(out_dir, "example3_new_sample_corrected_features.csv"),
  row.names = FALSE
)

display_x <- rbind(
  training_x,
  new_original = new_sample,
  new_corrected = corrected_sample
)
pca_fit <- prcomp(display_x, center = TRUE, scale. = TRUE)
scores <- pca_fit$x[, 1:2, drop = FALSE]
training_scores <- scores[rownames(training_x), , drop = FALSE]
new_original_score <- scores["new_original", , drop = FALSE]
new_corrected_score <- scores["new_corrected", , drop = FALSE]

center_scores <- aggregate(training_scores, by = list(domain = training_domain), FUN = mean)
center_scores <- center_scores[match(c("COADREAD", "STAD", "PAAD"), center_scores$domain), ]
all_display_scores <- rbind(training_scores, center_scores[, c("PC1", "PC2")], new_original_score, new_corrected_score)
x_limits <- range(all_display_scores[, 1])
y_limits <- range(all_display_scores[, 2])
x_limits <- x_limits + c(-1, 1) * 0.08 * diff(x_limits)
y_limits <- y_limits + c(-1, 1) * 0.10 * diff(y_limits)

domain_colors <- c(COADREAD = "#2f6fbb", STAD = "#c94f44", PAAD = "#7a5aa6")
colors <- domain_colors[training_domain]

local({
png(file.path(out_dir, "example3_three_domain_new_sample_pca.png"), width = 1450, height = 980, res = 150)
example_device <- dev.cur()
on.exit(dev.off(example_device), add = TRUE)
plot(
  training_scores[, 1],
  training_scores[, 2],
  col = adjustcolor(colors, alpha.f = 0.50),
  pch = 16,
  xlim = x_limits,
  ylim = y_limits,
  xlab = "PC1",
  ylab = "PC2",
  main = paste0("Three-domain new sample correction, lambda = ", lambda),
  cex = 0.70
)
grid(col = "gray88")
polygon(
  center_scores$PC1,
  center_scores$PC2,
  border = "gray35",
  col = adjustcolor("gray70", alpha.f = 0.18),
  lwd = 2,
  lty = 2
)
points(
  center_scores$PC1,
  center_scores$PC2,
  pch = 23,
  bg = domain_colors[center_scores$domain],
  col = "black",
  cex = 2.3,
  lwd = 1.2
)
text(center_scores$PC1, center_scores$PC2, labels = paste0(" ", center_scores$domain), pos = 4, cex = 0.82)
points(new_original_score[, 1], new_original_score[, 2], pch = 4, cex = 2.2, lwd = 2.5, col = "black")
points(new_corrected_score[, 1], new_corrected_score[, 2], pch = 8, cex = 2.2, lwd = 2.5, col = "#1b9e77")
arrows(
  new_original_score[, 1],
  new_original_score[, 2],
  new_corrected_score[, 1],
  new_corrected_score[, 2],
  length = 0.10,
  lwd = 2,
  col = "#1b9e77"
)
legend(
  "topright",
  legend = c("COADREAD", "STAD", "PAAD", "domain-center triangle", "new sample original", "new sample corrected"),
  col = c(domain_colors, "gray35", "black", "#1b9e77"),
  pch = c(16, 16, 16, NA, 4, 8),
  lty = c(NA, NA, NA, 2, NA, NA),
  bty = "n"
)
})

print(projector)
print(head(corrected_sample, 10))
message("Example 3 outputs written to: ", out_dir)
