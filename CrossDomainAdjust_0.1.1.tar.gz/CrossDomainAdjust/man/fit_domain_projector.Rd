\name{fit_domain_projector}
\alias{fit_domain_projector}
\title{Fit a Cross-Domain Feature Projector}
\usage{
fit_domain_projector(x, domain, anchor = "domain_mean")
}
\arguments{
\item{x}{Numeric matrix or data frame with samples in rows and features in columns.}
\item{domain}{Character or factor vector giving the domain label for each row of \code{x}.}
\item{anchor}{Character string or named numeric vector. Use \code{"domain_mean"}
for the equal-weight mean of domain centroids, matching
\code{(mu_1 + ... + mu_K) / K}. Use \code{"sample_mean"} for the
sample-size-weighted feature mean. A named numeric vector can also be supplied
as a custom projection anchor.}
}
\value{An object of class \code{"domain_projector"}.}
\description{
Learns the low-dimensional subspace spanned by domain centroid differences and
stores the orthogonal projection matrix for that subspace.
For K domains, the learned domain-shift subspace has rank at most K - 1
when the anchor is in the affine hull of the centroids, including both
built-in anchors. An arbitrary custom anchor can give rank K, subject to
the number of features.
}
\examples{
set.seed(1)
x <- rbind(
  matrix(rnorm(20), nrow = 5),
  matrix(rnorm(20) + 1, nrow = 5),
  matrix(rnorm(20) - 1, nrow = 5)
)
colnames(x) <- paste0("feature_", seq_len(ncol(x)))
domain <- rep(c("A", "B", "C"), each = 5)

projector <- fit_domain_projector(x, domain, anchor = "domain_mean")
projector
}
