\name{project_features}
\alias{project_features}
\title{Project Features with a Fitted Cross-Domain Projector}
\usage{
project_features(projector, x, lambda = 1)
}
\arguments{
\item{projector}{A \code{"domain_projector"} returned by \code{fit_domain_projector()}.}
\item{x}{Numeric matrix, data frame, or named numeric vector of feature values.}
\item{lambda}{Numeric scalar in \code{[0, 1]}.}
}
\value{A numeric matrix with corrected features.}
\description{
Corrects feature values by removing a lambda-controlled fraction of the learned
domain-shift projection component:
\code{x_corrected = x - lambda * ((x - anchor) \%*\% P)}.
\code{lambda = 0} returns the original features. \code{lambda = 1} fully
projects away the learned cross-domain subspace.
}
\examples{
set.seed(2)
x <- rbind(
  matrix(rnorm(20), nrow = 5),
  matrix(rnorm(20) + 1, nrow = 5)
)
colnames(x) <- paste0("feature_", seq_len(ncol(x)))
domain <- rep(c("A", "B"), each = 5)

projector <- fit_domain_projector(x, domain)
project_features(projector, x, lambda = 0)
project_features(projector, x, lambda = 0.5)
project_features(projector, x, lambda = 1)
}
