\name{project_new_sample}
\alias{project_new_sample}
\title{Project One New Sample}
\usage{
project_new_sample(projector, sample, domain = NULL, lambda = 1)
}
\arguments{
\item{projector}{A \code{"domain_projector"} returned by \code{fit_domain_projector()}.}
\item{sample}{Named numeric vector, one-row data frame, or one-row matrix.}
\item{domain}{Optional source-domain label for the sample. If supplied, it must
match one of the training domains.}
\item{lambda}{Numeric scalar in \code{[0, 1]}.}
}
\value{A named numeric vector of corrected features.}
\description{
Convenience wrapper for correcting a single named feature vector.
}
\examples{
set.seed(3)
x <- rbind(
  matrix(rnorm(20), nrow = 5),
  matrix(rnorm(20) + 1, nrow = 5)
)
colnames(x) <- paste0("feature_", seq_len(ncol(x)))
domain <- rep(c("A", "B"), each = 5)

projector <- fit_domain_projector(x, domain)
new_sample <- setNames(rnorm(ncol(x)) + 1, colnames(x))
project_new_sample(projector, new_sample, domain = "B", lambda = 0.8)
}
