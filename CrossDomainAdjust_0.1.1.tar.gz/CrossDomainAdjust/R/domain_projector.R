#' Fit a Cross-Domain Feature Projector
#'
#' Learns the low-dimensional subspace spanned by domain centroid differences and
#' stores the orthogonal projection matrix for that subspace.
#' This supports two, three, four, or more domains as long as each domain has at
#' least one training sample. For K domains, the learned domain-shift subspace
#' has rank at most K - 1 when the anchor is in the affine hull of the centroids
#' (including both built-in anchors). An arbitrary custom anchor can give rank K.
#'
#' @param x Numeric matrix or data frame with samples in rows and features in columns.
#' @param domain Character or factor vector giving the domain label for each row of `x`.
#' @param anchor Character string or named numeric vector. Use `"domain_mean"`
#'   for the equal-weight mean of domain centroids, matching
#'   `(mu_1 + ... + mu_K) / K`. Use `"sample_mean"` for the sample-size-weighted
#'   feature mean. A named numeric vector can also be supplied as a custom
#'   projection anchor.
#'
#' @return An object of class `"domain_projector"`.
#' @export
fit_domain_projector <- function(x, domain, anchor = "domain_mean") {
  x <- as_numeric_matrix(x)
  if (length(domain) != nrow(x)) {
    stop("`domain` length must equal the number of rows in `x`.", call. = FALSE)
  }

  domain <- as.character(domain)
  if (anyNA(domain) || any(domain == "")) {
    stop("`domain` must not contain NA or empty labels.", call. = FALSE)
  }
  domain_levels <- unique(domain)
  if (length(domain_levels) < 2) {
    stop("At least two domains are required.", call. = FALSE)
  }

  domain_centers <- vapply(
    domain_levels,
    function(level) colMeans(x[domain == level, , drop = FALSE], na.rm = FALSE),
    numeric(ncol(x))
  )
  domain_centers <- t(domain_centers)
  rownames(domain_centers) <- domain_levels
  colnames(domain_centers) <- colnames(x)
  anchor_type <- NULL
  if (is.character(anchor) && length(anchor) == 1) {
    anchor_type <- anchor
    projection_anchor <- switch(
      anchor,
      domain_mean = colMeans(domain_centers, na.rm = FALSE),
      sample_mean = colMeans(x, na.rm = FALSE),
      stop(
        "`anchor` must be 'domain_mean', 'sample_mean', or a named numeric vector.",
        call. = FALSE
      )
    )
  } else if (is.numeric(anchor) && !is.null(names(anchor))) {
    anchor_type <- "custom"
    missing <- setdiff(colnames(x), names(anchor))
    if (length(missing) > 0) {
      stop("Custom `anchor` is missing features: ", paste(missing, collapse = ", "), call. = FALSE)
    }
    projection_anchor <- as.numeric(anchor[colnames(x)])
    names(projection_anchor) <- colnames(x)
    if (anyNA(projection_anchor)) {
      stop("Custom `anchor` must not contain missing values.", call. = FALSE)
    }
  } else {
    stop("`anchor` must be 'domain_mean', 'sample_mean', or a named numeric vector.", call. = FALSE)
  }

  shift_matrix <- sweep(domain_centers, 2, projection_anchor, FUN = "-")
  svd_fit <- svd(shift_matrix)
  tol <- max(dim(shift_matrix)) * .Machine$double.eps * max(svd_fit$d)
  rank <- sum(svd_fit$d > tol)
  basis <- if (rank == 0) {
    matrix(0, nrow = ncol(x), ncol = 0, dimnames = list(colnames(x), NULL))
  } else {
    svd_fit$v[, seq_len(rank), drop = FALSE]
  }
  rownames(basis) <- colnames(x)
  projection_matrix <- basis %*% t(basis)
  rownames(projection_matrix) <- colnames(x)
  colnames(projection_matrix) <- colnames(x)

  structure(
    list(
      feature_names = colnames(x),
      domain_levels = domain_levels,
      projection_anchor = projection_anchor,
      domain_centers = domain_centers,
      shift_matrix = shift_matrix,
      basis = basis,
      projection_matrix = projection_matrix,
      rank = rank,
      anchor = projection_anchor,
      anchor_type = anchor_type
    ),
    class = "domain_projector"
  )
}

#' Project Features with a Fitted Cross-Domain Projector
#'
#' Corrects feature values by removing a lambda-controlled fraction of the
#' learned domain-shift projection component:
#' `x_corrected = x - lambda * ((x - anchor) %*% P)`.
#' `lambda = 0` returns the original features. `lambda = 1` fully projects away
#' the learned cross-domain subspace.
#'
#' @param projector A `"domain_projector"` returned by [fit_domain_projector()].
#' @param x Numeric matrix, data frame, or named numeric vector of feature values.
#' @param lambda Numeric scalar in `[0, 1]`.
#'
#' @return A numeric matrix with corrected features.
#' @export
project_features <- function(projector, x, lambda = 1) {
  validate_projector(projector)
  validate_lambda(lambda)

  x <- as_numeric_matrix(x)
  x <- align_features(x, projector$feature_names)
  if (projector$rank == 0 || lambda == 0) {
    return(x)
  }

  shifted <- sweep(x, 2, projector$projection_anchor, FUN = "-")
  projected_component <- shifted %*% projector$projection_matrix
  corrected <- x - lambda * projected_component
  colnames(corrected) <- projector$feature_names
  rownames(corrected) <- rownames(x)
  corrected
}

#' Project One New Sample
#'
#' Convenience wrapper for correcting a single named feature vector. The
#' `domain` argument is recorded in the output attributes so downstream code can
#' keep the sample's source domain, but the projection itself uses the globally
#' learned domain-shift subspace.
#'
#' @param projector A `"domain_projector"` returned by [fit_domain_projector()].
#' @param sample Named numeric vector, one-row data frame, or one-row matrix.
#' @param domain Optional source-domain label for the sample.
#' @param lambda Numeric scalar in `[0, 1]`.
#'
#' @return A named numeric vector of corrected features.
#' @export
project_new_sample <- function(projector, sample, domain = NULL, lambda = 1) {
  validate_projector(projector)
  if (!is.null(domain)) {
    domain <- as.character(domain)
    if (length(domain) != 1 || is.na(domain) || domain == "") {
      stop("`domain` must be NULL or one non-empty domain label.", call. = FALSE)
    }
    if (!domain %in% projector$domain_levels) {
      stop(
        "`domain` must be one of the training domains: ",
        paste(projector$domain_levels, collapse = ", "),
        call. = FALSE
      )
    }
  }
  corrected <- project_features(projector, sample, lambda = lambda)
  out <- as.numeric(corrected[1, ])
  names(out) <- colnames(corrected)
  attr(out, "domain") <- domain
  attr(out, "lambda") <- lambda
  out
}

#' @export
print.domain_projector <- function(x, ...) {
  cat("Cross-domain feature projector\n")
  cat("  Features:", length(x$feature_names), "\n")
  cat("  Domains:", paste(x$domain_levels, collapse = ", "), "\n")
  cat("  Projection rank:", x$rank, "\n")
  cat("  Anchor:", x$anchor_type, "\n")
  cat("  Lambda rule: corrected = x - lambda * domain_projection(x)\n")
  invisible(x)
}

as_numeric_matrix <- function(x) {
  if (is.vector(x) && is.numeric(x)) {
    if (is.null(names(x))) {
      stop("A numeric vector input must have feature names.", call. = FALSE)
    }
    x <- matrix(x, nrow = 1, dimnames = list(NULL, names(x)))
  } else if (is.data.frame(x)) {
    x <- as.matrix(x)
  } else {
    x <- as.matrix(x)
  }

  storage.mode(x) <- "double"
  if (!is.numeric(x)) {
    stop("`x` must contain numeric feature values.", call. = FALSE)
  }
  if (is.null(colnames(x)) || any(colnames(x) == "")) {
    stop("`x` must have non-empty feature column names.", call. = FALSE)
  }
  if (anyNA(x)) {
    stop("Missing feature values are not supported.", call. = FALSE)
  }
  x
}

align_features <- function(x, feature_names) {
  missing <- setdiff(feature_names, colnames(x))
  extra <- setdiff(colnames(x), feature_names)
  if (length(missing) > 0) {
    stop("Input is missing required features: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  if (length(extra) > 0) {
    x <- x[, feature_names, drop = FALSE]
  } else {
    x <- x[, feature_names, drop = FALSE]
  }
  x
}

validate_lambda <- function(lambda) {
  if (!is.numeric(lambda) || length(lambda) != 1 || is.na(lambda)) {
    stop("`lambda` must be one numeric value.", call. = FALSE)
  }
  if (lambda < 0 || lambda > 1) {
    stop("`lambda` must be between 0 and 1.", call. = FALSE)
  }
  invisible(TRUE)
}

validate_projector <- function(projector) {
  if (!inherits(projector, "domain_projector")) {
    stop("`projector` must be created by fit_domain_projector().", call. = FALSE)
  }
  invisible(TRUE)
}
